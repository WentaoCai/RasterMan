# ============================================================================
# RasterMan - Trans-eQTL Manhattan Plot Module
# ============================================================================

#' @importFrom ggplot2 ggplot aes geom_point geom_hline geom_rect geom_text
#'   scale_x_continuous scale_y_continuous scale_color_gradient2 scale_size_continuous
#'   theme_classic theme element_blank element_text labs ggsave
#' @importFrom dplyr filter mutate group_by summarise arrange left_join select
#' @importFrom magrittr %>%
#' @importFrom data.table fread
NULL

# Package-aware rasterization check
.check_rasterization_pkg <- function() {
  required <- c("rasterize_smart", "rasterize_multilevel",
                "rasterize_adaptive_density", "rasterize_basic",
                "analyze_data_distribution")
  available <- all(vapply(required, existsMethod_safe, logical(1)))
  if (available)
    list(available = TRUE,  message = "Rasterization functions loaded")
  else
    list(available = FALSE, message = "C++ rasterization module not compiled")
}

#!/usr/bin/env Rscript
# ============================================================================
# Trans-eQTL Manhattan Plot Tool (Enhanced Version)
# ============================================================================
# 
# Purpose: 2D Manhattan plot for trans-eQTL, with rasterization acceleration
# 
# Features:
#   - 2D Manhattan: X = SNP position, Y = gene position
#   - Rasterization: supports tens-of-millions of data points
#   - Color encodes effect direction (Slope/Effect) - optional
#   - Size encodes significance (-log10 P)
#   - Chromosome background grid
#   - Supports chr prefix and X/Y/MT chromosomes
#   - effect parameter optional (NULL-safe)
# 
# Author: WentaoCai
# Date: 2026-02-28
# Version: v2.1 (Enhanced)
# ============================================================================

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(ggplot2)
})

# ============================================================================
# Helper: chromosome normalisation
# ============================================================================

.normalize_chromosome <- function(chr, max_auto = NULL) {
  # Convert to string, save original label
  chr       <- as.character(chr)
  chr_label <- chr

  # Strip chr/Chr/CHR prefix
  chr <- sub("^[Cc][Hh][Rr]", "", chr)

  # Convert numeric chromosomes first to determine max autosome number
  int_x <- suppressWarnings(as.integer(chr))
  if (is.null(max_auto)) {
    max_auto <- max(int_x, na.rm = TRUE)
    if (!is.finite(max_auto)) max_auto <- 0L
  }

  # Non-numeric labels assigned from max_auto+1 in fixed priority order
  special_order  <- c("X","x","Y","y","Z","z","W","w","MT","Mt","mt","M","m")
  non_num        <- unique(chr[is.na(int_x)])
  in_special     <- non_num[non_num %in% special_order]
  not_special    <- sort(non_num[!non_num %in% special_order])
  ordered_labels <- c(special_order[special_order %in% in_special], not_special)
  ordered_labels <- ordered_labels[!duplicated(toupper(ordered_labels))]

  if (length(ordered_labels) > 0) {
    offset <- max_auto + 1L
    for (i in seq_along(ordered_labels)) {
      int_x[tolower(chr) == tolower(ordered_labels[i])] <- offset + i - 1L
    }
    cat(sprintf(
      "  Chromosome mapping (max autosome=%d): %s\n",
      max_auto,
      paste(sprintf("%s→%d", ordered_labels, offset + seq_along(ordered_labels) - 1L),
            collapse = ", ")
    ))
  }

  list(chr_num = int_x, chr_label = chr_label)
}

# ============================================================================
# Check rasterization functions
# ============================================================================

.check_rasterization_available_orig <- function() {
  # Try multiple possible paths
  possible_paths <- c(
    "gwas_smart_rasterization.cpp",
    "./gwas_smart_rasterization.cpp",
    file.path(getwd(), "gwas_smart_rasterization.cpp"),
    file.path(getwd(), "cpp", "gwas_smart_rasterization.cpp")
  )
  
  cat("\nSearching for C++ file...\n")
  
  cpp_file <- NULL
  for(path in possible_paths) {
    if(file.exists(path)) {
      cpp_file <- path
      cat(sprintf("Found: %s\n", path))
      break
    }
  }
  
  if(is.null(cpp_file)) {
    return(list(available = FALSE, message = "C++ source file not found"))
  }
  
  # Check if Rcpp is available
  if(!requireNamespace("Rcpp", quietly = TRUE)) {
    return(list(
      available = FALSE,
      message = "Rcpp package not installed. Run: install.packages('Rcpp')"
    ))
  }
  
  # Try loading
  tryCatch({
    suppressMessages({
      Rcpp::sourceCpp(cpp_file)
    })
    
    # Test function
    test_result <- rasterize_basic(
      c(1, 2, 3), c(1, 2, 3), c(1, 1, 1),
      10, 10, 0, 10, 0, 10, 1
    )
    
    return(list(
      available = TRUE,
      message = "Rasterization available",
      source = cpp_file
    ))
    
  }, error = function(e) {
    return(list(
      available = FALSE,
      message = sprintf("Load failed: %s", e$message)
    ))
  })
}

# ============================================================================
# Data preparation (enhanced: optional parameters and chr prefix support)
# ============================================================================

#' Prepare trans-eQTL data
#' @export
prepare_trans_eqtl_data <- function(data, 
                                     chr_col = "Chr",
                                     pos_col = "Pos",
                                     p_col = "Pvalue",
                                     gene_chr_col = "Gene_chr",
                                     gene_start_col = "Start",
                                     gene_end_col = "End",
                                     snp_col = NULL,        # optional
                                     gene_col = NULL,       # optional
                                     slope_col = NULL) {    # optional
  
  cat("\n=== Data preparation ===\n")
  
  # ========================================================================
  # Check required columns
  # ========================================================================
  required_cols <- c(chr_col, pos_col, p_col, 
                    gene_chr_col, gene_start_col, gene_end_col)
  missing_cols <- setdiff(required_cols, colnames(data))
  
  if(length(missing_cols) > 0) {
    cat(sprintf("Error: column(s) not found: %s\n", paste(missing_cols, collapse = ", ")))
    cat("\nAvailable column names:\n")
    print(colnames(data))
    stop("Column name mismatch")
  }
  
  # ========================================================================
  # Check optional columns
  # ========================================================================
  has_snp <- !is.null(snp_col) && snp_col %in% colnames(data)
  has_gene <- !is.null(gene_col) && gene_col %in% colnames(data)
  has_slope <- !is.null(slope_col) && slope_col %in% colnames(data)
  
  cat(sprintf("Optional column status:\n"))
  cat(sprintf("  SNP ID column: %s\n", ifelse(has_snp, paste0("✓ ", snp_col), "absent, will auto-generate")))
  cat(sprintf("  Gene column: %s\n", ifelse(has_gene, paste0("✓ ", gene_col), "absent, not used")))
  cat(sprintf("  Slope/Effect column: %s\n", ifelse(has_slope, paste0("✓ ", slope_col), "absent, will use P-value colouring")))
  
  # ========================================================================
  # Column name mapping
  # ========================================================================
  data.table::setDT(data)
  
  # Rename required columns
  data.table::setnames(data, old = chr_col, new = "CHR")
  data.table::setnames(data, old = pos_col, new = "POS")
  data.table::setnames(data, old = p_col, new = "P")
  data.table::setnames(data, old = gene_chr_col, new = "GENE_CHR")
  data.table::setnames(data, old = gene_start_col, new = "GENE_START")
  data.table::setnames(data, old = gene_end_col, new = "GENE_END")
  
  # Rename optional columns
  if(has_snp) data.table::setnames(data, old = snp_col, new = "SNP")
  if(has_gene) data.table::setnames(data, old = gene_col, new = "GENE")
  if(has_slope) data.table::setnames(data, old = slope_col, new = "SLOPE")
  
  cat("Column mapping complete\n")
  
  # ========================================================================
  # Chromosome normalisation (supports chr prefix and X/Y/MT)
  # ========================================================================
  cat("Normalising chromosomes...\n")
  
  # Scan both SNP and gene chromosomes to find shared max autosome number
  # Ensures non-numeric labels get the same number in both groups (e.g. cattle X → 30)
  tmp_snp  <- suppressWarnings(as.integer(sub("^[Cc][Hh][Rr]", "", as.character(data$CHR))))
  tmp_gene <- suppressWarnings(as.integer(sub("^[Cc][Hh][Rr]", "", as.character(data$GENE_CHR))))
  max_auto <- max(c(tmp_snp, tmp_gene), na.rm = TRUE)
  if (!is.finite(max_auto)) max_auto <- 0L

  # Normalise SNP chromosomes
  snp_chr_result <- .normalize_chromosome(data$CHR, max_auto = max_auto)
  data[, CHR_num   := snp_chr_result$chr_num]
  data[, CHR_label := snp_chr_result$chr_label]

  # Normalise gene chromosomes (shared max_auto for consistent numbering)
  gene_chr_result <- .normalize_chromosome(data$GENE_CHR, max_auto = max_auto)
  data[, GENE_CHR_num   := gene_chr_result$chr_num]
  data[, GENE_CHR_label := gene_chr_result$chr_label]

  # Detect special chromosomes and report
  has_chr_prefix <- any(grepl("^[Cc][Hh][Rr]", c(data$CHR_label, data$GENE_CHR_label)))
  if (has_chr_prefix) cat("  Detected 'chr' prefix, stripped automatically\n")
  
  # ========================================================================
  # Convert data types and filter
  # ========================================================================
  cat("Data cleaning...\n")
  
  data[, POS := as.numeric(POS)]
  data[, GENE_START := as.numeric(GENE_START)]
  data[, GENE_END := as.numeric(GENE_END)]
  data[, P := as.numeric(P)]
  
  # Process slope column (if present)
  if(has_slope) {
    data[, SLOPE := as.numeric(SLOPE)]
    slope_valid <- sum(!is.na(data$SLOPE) & is.finite(data$SLOPE))
    slope_total <- nrow(data)
    cat(sprintf("  Slope column: %d / %d valid values (%.1f%%)\n", 
                slope_valid, slope_total, 100 * slope_valid / slope_total))
    
    if(slope_valid == 0) {
      cat("  Slope column has no valid values, will use P-value colouring\n")
      has_slope <- FALSE
      data[, SLOPE := NULL]
    }
  }
  
  # Generate SNP IDs (if absent)
  if(!has_snp) {
    data[, SNP := paste0(CHR_label, ":", POS)]
    cat("  Auto-generated SNP IDs (format: chr:pos)\n")
  }
  
  # Filter invalid data
  n_before <- nrow(data)
  data <- data[
    !is.na(CHR_num) & !is.na(POS) & !is.na(GENE_CHR_num) & 
    !is.na(P) &
    CHR_num > 0 & CHR_num <= 100 &
    GENE_CHR_num > 0 & GENE_CHR_num <= 100 &
    P > 0 & P <= 1
  ]
  
  n_filtered <- n_before - nrow(data)
  if(n_filtered > 0) {
    cat(sprintf("  Filtered out %s invalid rows (%.2f%%)\n", 
                format(n_filtered, big.mark = ","),
                100 * n_filtered / n_before))
  }
  
  # Compute LOG10P and gene midpoint positions
  data[, LOG10P := -log10(P)]
  data[, GENE_POS := (GENE_START + GENE_END) / 2]
  
  cat(sprintf("Valid rows: %s\n", format(nrow(data), big.mark = ",")))
  cat(sprintf("  SNP chromosomes: %d\n", data.table::uniqueN(data$CHR_num)))
  cat(sprintf("  Gene chromosomes: %d\n", data.table::uniqueN(data$GENE_CHR_num)))
  
  # ========================================================================
  # Compute cumulative positions
  # ========================================================================
  cat("Computing cumulative positions...\n")
  
  # SNP chromosome info
  snp_chr_info <- data[, .(chr_len = max(POS)), by = CHR_num]
  data.table::setorder(snp_chr_info, CHR_num)
  
  snp_chr_info[, chr_len := as.numeric(chr_len)]
  snp_chr_info[, total := cumsum(chr_len) - chr_len]
  snp_chr_info[, total := ceiling(total / 1e7) * 1e7]  # align to 10 Mb
  snp_chr_info[, chr_end := total + chr_len]
  snp_chr_info[, chr_center := total + chr_len / 2]
  
  # Get CHR_label (first label per CHR_num)
  chr_labels_snp <- data[, .(CHR_label = first(CHR_label)), by = CHR_num]
  snp_chr_info <- snp_chr_info[chr_labels_snp, on = "CHR_num"]
  data.table::setnames(snp_chr_info, "CHR_num", "CHR")
  
  # Gene chromosome info
  gene_chr_info <- data[, .(chr_len = max(GENE_POS)), by = GENE_CHR_num]
  data.table::setorder(gene_chr_info, GENE_CHR_num)
  
  gene_chr_info[, chr_len := as.numeric(chr_len)]
  gene_chr_info[, total := cumsum(chr_len) - chr_len]
  gene_chr_info[, total := ceiling(total / 1e7) * 1e7]
  gene_chr_info[, chr_end := total + chr_len]
  gene_chr_info[, chr_center := total + chr_len / 2]
  
  # Get GENE_CHR_label
  chr_labels_gene <- data[, .(GENE_CHR_label = first(GENE_CHR_label)), by = GENE_CHR_num]
  gene_chr_info <- gene_chr_info[chr_labels_gene, on = "GENE_CHR_num"]
  data.table::setnames(gene_chr_info, "GENE_CHR_num", "GENE_CHR")
  
  # Add cumulative positions to data
  data.table::setkey(data, CHR_num)
  data.table::setkey(snp_chr_info, CHR)
  data[snp_chr_info, POS_CUM := POS + i.total]
  
  data.table::setkey(data, GENE_CHR_num)
  data.table::setkey(gene_chr_info, GENE_CHR)
  data[gene_chr_info, GENE_POS_CUM := GENE_POS + i.total]
  
  cat(sprintf("  SNP position range: %.0f - %.0f\n", 
              min(data$POS_CUM, na.rm = TRUE), 
              max(data$POS_CUM, na.rm = TRUE)))
  cat(sprintf("  Gene position range: %.0f - %.0f\n",
              min(data$GENE_POS_CUM, na.rm = TRUE), 
              max(data$GENE_POS_CUM, na.rm = TRUE)))
  
  # ========================================================================
  # Return results
  # ========================================================================
  cat("✓ Data preparation complete\n")
  
  return(list(
    data = data,
    snp_chr_info = snp_chr_info,
    gene_chr_info = gene_chr_info,
    has_slope = has_slope
  ))
}

# ============================================================================
# Rasterization strategy decision
# ============================================================================

.decide_rasterization <- function(n_points, force_raster, no_raster, method) {
  if(no_raster) {
    return(list(use = FALSE, method = "standard", 
                reason = "rasterization disabled by user"))
  }
  
  if(force_raster) {
    return(list(use = TRUE, method = method, 
                reason = "rasterization forced by user"))
  }
  
  if(n_points < 100000) {
    return(list(use = FALSE, method = "standard",
                reason = sprintf("Small dataset (%s points), using standard plot", 
                                format(n_points, big.mark = ","))))
  } else {
    cat("\n", strrep("=", 77), "\n", sep="")
    cat("Smart rasterization decision\n")
    cat(strrep("=", 77), "\n")
    cat(sprintf("Your data has %s points.\n\n", format(n_points, big.mark = ",")))
    cat("Using smart rasterization to accelerate plotting (3-4x), features:\n")
    cat("  Preserves visual information of all points (colour gradient + size variation)\n")
    cat("  No scatter data lost\n")
    cat("  Optimised rendering performance\n\n")
    cat(strrep("=", 77), "\n\n")
    
    return(list(use = TRUE, method = "basic",
                reason = sprintf("Large dataset (%s points), using smart rasterization", 
                                format(n_points, big.mark = ","))))
  }
}

# ============================================================================
# Smart rasterization (optional effect support)
# ============================================================================

smart_rasterize_trans_eqtl <- function(data, raster_size = 2000,
                                       has_slope = TRUE,
                                       slope_bins = 15,
                                       slope_cap_quantile = 0.999) {
  cat("\nUsing smart rasterization\n")
  cat(sprintf("Raw data: %s points\n", format(nrow(data), big.mark = ",")))
  cat(sprintf("Grid size: %d x %d\n", raster_size, raster_size))
  
  # ========================================================================
  # Handle colour values (slope or P-value)
  # ========================================================================
  if(has_slope && "SLOPE" %in% names(data)) {
    cat("Colour encoding: Effect/Slope (blue->white->red)\n")
    
    # Discretise SLOPE
    slope <- data$SLOPE
    slope <- slope[is.finite(slope)]
    
    if(length(slope) == 0) {
      cat("  SLOPE all NA/Inf, switching to P-value colouring\n")
      has_slope <- FALSE
    } else {
      # Clip extreme values using quantiles
      cap <- as.numeric(stats::quantile(abs(slope), probs = slope_cap_quantile, na.rm = TRUE))
      if(!is.finite(cap) || cap <= 0) cap <- max(abs(slope), na.rm = TRUE)
      
      # Symmetric range
      slope_breaks <- seq(-cap, cap, length.out = slope_bins + 1)
      bin_midpoints <- (slope_breaks[-1] + slope_breaks[-length(slope_breaks)]) / 2
      
      cat(sprintf("  SLOPE range: [%.4g, %.4g]\n", min(slope_breaks), max(slope_breaks)))
      cat(sprintf("  Colour bins: %d (symmetric)\n", slope_bins))
      
      # Bin
      data <- data %>%
        mutate(
          slope_bin = cut(SLOPE,
                          breaks = slope_breaks,
                          labels = seq_len(slope_bins),
                          include.lowest = TRUE,
                          right = TRUE),
          slope_bin = as.integer(as.character(slope_bin))
        )
      
      # Handle out-of-range values
      data <- data %>%
        mutate(
          slope_bin = dplyr::case_when(
            !is.na(slope_bin) ~ slope_bin,
            is.na(SLOPE) | !is.finite(SLOPE) ~ NA_integer_,
            SLOPE < 0 ~ 1L,
            TRUE ~ slope_bins
          )
        )
      
      color_col <- "slope_bin"
    }
  }
  
  if(!has_slope) {
    cat("Colour encoding: -log10(P) (viridis scale)\n")
    
    # Bin by LOG10P
    data <- data %>%
      mutate(
        p_bin = cut(LOG10P,
                    breaks = 15,
                    labels = 1:15),
        p_bin = as.integer(as.character(p_bin))
      )
    
    color_col <- "p_bin"
  }
  
  # ========================================================================
  # Compute grid
  # ========================================================================
  x_range <- range(data$POS_CUM, na.rm = TRUE)
  y_range <- range(data$GENE_POS_CUM, na.rm = TRUE)
  
  data <- data %>%
    mutate(
      grid_x = pmin(raster_size, pmax(1, 
                    ceiling((POS_CUM - x_range[1]) / (x_range[2] - x_range[1]) * raster_size))),
      grid_y = pmin(raster_size, pmax(1,
                    ceiling((GENE_POS_CUM - y_range[1]) / (y_range[2] - y_range[1]) * raster_size))),
      grid_key = paste(grid_x, grid_y, .data[[color_col]], sep = "_")
    )
  
  # ========================================================================
  # Grid aggregation
  # ========================================================================
  if(has_slope) {
    # Save bin_midpoints to outer scope
    bins_midpoints <- bin_midpoints
    
    grid_summary <- data %>%
      group_by(grid_key, grid_x, grid_y, slope_bin) %>%
      summarise(
        median_p = median(P),
        median_slope = median(SLOPE, na.rm = TRUE),  # use median slope
        x_pos = mean(POS_CUM),
        y_pos = mean(GENE_POS_CUM),
        .groups = 'drop'
      ) %>%
      mutate(
        # use median_slope directly instead of bin_midpoints mapping
        slope_value = median_slope
      )
    
    cat(sprintf("  slope_value range: [%.4g, %.4g]\n", 
                min(grid_summary$slope_value, na.rm = TRUE),
                max(grid_summary$slope_value, na.rm = TRUE)))
    
  } else {
    grid_summary <- data %>%
      group_by(grid_key, grid_x, grid_y, p_bin) %>%
      summarise(
        median_p = median(P),
        x_pos = mean(POS_CUM),
        y_pos = mean(GENE_POS_CUM),
        median_log10p = median(LOG10P),
        .groups = 'drop'
      )
  }
  
  # Randomise plot order
  set.seed(12345)
  grid_summary <- grid_summary[sample(nrow(grid_summary)), ]
  
  cat(sprintf("Compression: %s points -> %s points (%.1fx)\n",
              format(nrow(data), big.mark = ","),
              format(nrow(grid_summary), big.mark = ","),
              nrow(data) / nrow(grid_summary)))
  cat("✓ Rasterization complete\n")
  
  return(list(
    data = grid_summary,
    has_slope = has_slope
  ))
}

# ============================================================================
# Rasterized plot function (optional effect support)
# ============================================================================

#' @export
plot_trans_manhattan_rasterized <- function(data, snp_chr_info, gene_chr_info, params) {
  # raster_method: "basic" (rasterized) or "off" (standard direct plot)
  raster_method <- if (!is.null(params$raster_method)) params$raster_method else "basic"
  if (!raster_method %in% c("basic", "off"))
    stop(sprintf("raster_method must be 'basic' or 'off', got: '%s'", raster_method))

  # Compatibility: support both old and new call signatures
  if(is.list(data) && "data" %in% names(data)) {
    prep_result  <- data
    data_orig    <- prep_result$data
    snp_chr_info  <- prep_result$snp_chr_info
    gene_chr_info <- prep_result$gene_chr_info
    has_slope    <- prep_result$has_slope
  } else {
    data_orig <- data
    has_slope <- "SLOPE" %in% names(data_orig) &&
                 sum(!is.na(data_orig$SLOPE) & is.finite(data_orig$SLOPE)) > 0
  }
  

  # ── Colour scheme (calls resolve_trans_color_scheme from utils.R) ────────
  .grad <- resolve_trans_color_scheme(
    scheme = params$color_scheme,
    low    = params$color_low,
    high   = params$color_high
  )
  params$color_low  <- .grad$low
  params$color_high <- .grad$high

  # ── raster_method = "off": standard direct plot ──────────────────────────────────
  if (raster_method == "off") {
    cat("\n=== Plotting (standard, no rasterization) ===\n")
    p <- ggplot(data_orig, aes(x = POS_CUM, y = GENE_POS_CUM))
    if (params$show_background) {
      xmin <- min(data_orig$POS_CUM); xmax <- max(data_orig$POS_CUM)
      ymin <- min(data_orig$GENE_POS_CUM); ymax <- max(data_orig$GENE_POS_CUM)
      for (i in 1:nrow(snp_chr_info)) {
        if (i %% 2 == 1)
          p <- p + annotate("rect",
            xmin = snp_chr_info$total[i], xmax = snp_chr_info$chr_end[i],
            ymin = ymin, ymax = ymax, fill = "grey80", alpha = 0.3)
      }
      for (i in 1:nrow(gene_chr_info)) {
        if (i %% 2 == 1)
          p <- p + annotate("rect",
            xmin = xmin, xmax = xmax,
            ymin = gene_chr_info$total[i], ymax = gene_chr_info$chr_end[i],
            fill = "grey80", alpha = 0.3)
      }
    }
    if (has_slope) {
      cat("Using Effect gradient colouring\n")
      p <- p +
        geom_point(aes(fill = SLOPE, size = LOG10P),
                   shape = 21, alpha = 0.8, color = "grey10", stroke = 0.2) +
        scale_fill_gradient2(low = params$color_low, high = params$color_high,
                             mid = "white", midpoint = 0, name = "Effect")
    } else {
      cat("Using P-value colouring (default)\n")
      p <- p +
        geom_point(aes(color = LOG10P, size = LOG10P), alpha = 0.8) +
        scale_color_viridis_c(option = "plasma", name = "-log10(P)")
    }
    p <- p +
      scale_size_continuous(range = params$size_range, name = "-log10(P)") +
      scale_x_continuous(breaks = snp_chr_info$chr_center, labels = snp_chr_info$CHR_label,
                         expand = c(0.01, 0), guide = guide_axis(check.overlap = TRUE)) +
      scale_y_continuous(breaks = gene_chr_info$chr_center, labels = gene_chr_info$GENE_CHR_label,
                         expand = c(0.01, 0), guide = guide_axis(check.overlap = TRUE)) +
      labs(x = "Variant Position (Chromosome)", y = "Gene Position (Chromosome)",
           title = params$title) +
      theme(plot.title = element_text(size = 14, hjust = 0.5, face = "bold"),
            axis.title = element_text(size = 16, face = "bold"),
            axis.text  = element_text(size = 10),
            panel.background = element_blank(), aspect.ratio = 1,
            panel.border = element_rect(colour = "black", fill = NA, linewidth = 1),
            panel.grid.minor = element_line(colour = "darkgrey"),
            panel.grid.major = element_blank())
    return(p)
  }

  # ── raster_method = "basic": C++ rasterized plot ─────────────────────────────
  cat("\n=== Plotting (smart rasterization) ===\n")
  # Run rasterization
  start_time <- Sys.time()
  
  raster_size <- if (!is.null(params$raster_width)) params$raster_width else 2000L
  
  raster_result <- smart_rasterize_trans_eqtl(
    data_orig, 
    raster_size = raster_size,
    has_slope = has_slope
  )
  
  raster_data <- raster_result$data
  has_slope <- raster_result$has_slope
  
  elapsed <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
  cat(sprintf("Elapsed time: %.2f  seconds\n", elapsed))
  
  # Get range
  xmin <- min(data_orig$POS_CUM, na.rm = TRUE)
  xmax <- max(data_orig$POS_CUM, na.rm = TRUE)
  ymin <- min(data_orig$GENE_POS_CUM, na.rm = TRUE)
  ymax <- max(data_orig$GENE_POS_CUM, na.rm = TRUE)
  
  # Build plot
  p <- ggplot(raster_data, aes(x = x_pos, y = y_pos))
  
  # Add chromosome background
  if(params$show_background) {
    for(i in 1:nrow(snp_chr_info)) {
      if(i %% 2 == 1) {
        p <- p + annotate("rect",
                         xmin = snp_chr_info$total[i],
                         xmax = snp_chr_info$chr_end[i],
                         ymin = ymin,
                         ymax = ymax,
                         fill = "grey80",
                         alpha = 0.3)
      }
    }
    
    for(i in 1:nrow(gene_chr_info)) {
      if(i %% 2 == 1) {
        p <- p + annotate("rect",
                         xmin = xmin,
                         xmax = xmax,
                         ymin = gene_chr_info$total[i],
                         ymax = gene_chr_info$chr_end[i],
                         fill = "grey80",
                         alpha = 0.3)
      }
    }
  }
  
  # Add data points
  if(has_slope) {
    # Effect colouring
    cat("Using Effect gradient colouring\n")
    p <- p + 
      geom_point(aes(fill = slope_value, 
                     size = -log10(median_p)),
                 shape = 21,
                 alpha = 0.8,
                 color = "grey10",
                 stroke = 0.2) +
      scale_fill_gradient2(
        low = params$color_low,
        high = params$color_high,
        mid = "white",
        midpoint = 0,
        name = "Effect"
      )
  } else {
    # P-value colouring
    cat("Using P-value colouring (default)\n")
    p <- p +
      geom_point(aes(color = median_log10p,
                     size = median_log10p),
                 alpha = 0.8) +
      scale_color_viridis_c(
        option = "plasma",
        name = "-log10(P)"
      )
  }
  
  # Size scale
  p <- p +
    scale_size_continuous(
      range = params$size_range,
      name = "-log10(P)"
    )
  
  # Axes
  p <- p +
    scale_x_continuous(
      breaks = snp_chr_info$chr_center,
      labels = snp_chr_info$CHR_label,
      expand = c(0.01, 0),
      guide = guide_axis(check.overlap = TRUE)
    ) +
    scale_y_continuous(
      breaks = gene_chr_info$chr_center,
      labels = gene_chr_info$GENE_CHR_label,
      expand = c(0.01, 0),
      guide = guide_axis(check.overlap = TRUE)
    )
  
  # Theme
  p <- p +
    labs(
      x = "Variant Position (Chromosome)",
      y = "Gene Position (Chromosome)",
      title = params$title
    ) +
    theme(
      plot.title = element_text(size = 14, hjust = 0.5, face = "bold"),
      axis.title = element_text(size = 16, face = "bold"),
      axis.text = element_text(size = 10),
      legend.position = "right",
      panel.background = element_blank(),
      aspect.ratio = 1,
      panel.border = element_rect(colour = "black", fill = NA, linewidth = 1),
      panel.grid.minor = element_line(colour = "darkgrey"),
      panel.grid.major = element_blank()
    )
  
  return(p)
}

# ============================================================================
# Standard plot function (optional effect support)
# ============================================================================


# ============================================================================
# Parse arguments
# ============================================================================


.trans_parse_args <- function(args) {
  if(length(args) == 0 || args[1] == "--help" || args[1] == "-h") {
    .trans_print_help()
    quit(save = "no")
  }
  
  params <- list(
    input_file = args[1],
    output_file = "trans_eqtl_manhattan.png",
    # Column names
    chr_col = "Chr",
    pos_col = "Pos",
    snp_col = NULL,           # default NULL
    gene_col = NULL,          # default NULL
    p_col = "Pvalue",
    slope_col = NULL,         # default NULL (optional)
    gene_chr_col = "Gene_chr",
    gene_start_col = "Start",
    gene_end_col = "End",
    # Plot parameters
    width = 10,
    height = 10,
    dpi = 300,
    title = "trans-eQTL Manhattan Plot",
    # Colour parameters
    color_scheme = NULL,   # if set, overrides color_low/color_high
    color_low = "blue",
    color_high = "red",
    size_range = c(0.5, 3),
    log_base = 10,
    # Rasterization parameters
    raster_method = "auto",
    raster_width = 2000L,
    raster_height = 1000L,
    target_points = 50000,
    force_raster = FALSE,
    no_raster = FALSE,
    # Style parameters
    show_background = TRUE
  )
  
  i <- 2
  while(i <= length(args)) {
    arg <- args[i]
    
    if(arg == "-o" || arg == "--output") {
      params$output_file <- args[i+1]
      i <- i + 2
    } else if(arg == "--chr-col") {
      params$chr_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--pos-col") {
      params$pos_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--snp-col") {
      params$snp_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--gene-col") {
      params$gene_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--p-col") {
      params$p_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--slope-col" || arg == "--effect-col") {
      params$slope_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--gene-chr-col") {
      params$gene_chr_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--gene-start-col") {
      params$gene_start_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--gene-end-col") {
      params$gene_end_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--width") {
      params$width <- as.numeric(args[i+1])
      i <- i + 2
    } else if(arg == "--height") {
      params$height <- as.numeric(args[i+1])
      i <- i + 2
    } else if(arg == "--dpi") {
      params$dpi <- as.integer(args[i+1])
      i <- i + 2
    } else if(arg == "--title") {
      params$title <- args[i+1]
      i <- i + 2
    } else if(arg == "--raster-method") {
      params$raster_method <- args[i+1]
      i <- i + 2
    } else if(arg == "--raster-width") {
      params$raster_width <- as.integer(args[i+1])
      i <- i + 2
    } else if(arg == "--force-raster") {
      params$force_raster <- TRUE
      i <- i + 1
    } else if(arg == "--no-raster") {
      params$no_raster <- TRUE
      i <- i + 1
    } else if(arg == "--no-background") {
      params$show_background <- FALSE
      i <- i + 1
    } else if(arg == "--color-scheme") {
      params$color_scheme <- args[i+1]
      i <- i + 2
    } else if(arg == "--color-low") {
      params$color_low <- args[i+1]
      i <- i + 2
    } else if(arg == "--color-high") {
      params$color_high <- args[i+1]
      i <- i + 2
    } else {
      cat(sprintf("Warning: unknown argument '%s'\n", arg))
      i <- i + 1
    }
  }
  
  return(params)
}

.trans_print_help <- function() {
  cat("
Trans-eQTL Manhattan plot command-line tool (enhanced v2.1)

Usage:
  Rscript plot_trans_eqtl_manhattan_v2_enhanced.R <input_file> [options]

Required arguments:
  input_file              Input file (trans-eQTL results)

Output options:
  -o, --output FILE       Output filename (default: trans_eqtl_manhattan.png)
  --width INCHES          Plot width (default: 10)
  --height INCHES         Plot height (default: 10)
  --dpi DPI               Resolution (default: 300)
  --title TEXT            Plot title

Column name options:
  --chr-col NAME          SNP chromosome column (default: Chr)
  --pos-col NAME          SNP position column (default: Pos)
  --p-col NAME            P-value column (default: Pvalue)
  --gene-chr-col NAME     Gene chromosome column (default: Gene_chr)
  --gene-start-col NAME   Gene start position column (default: Start)
  --gene-end-col NAME     Gene end position column (default: End)
  
  Optional columns:
  --snp-col NAME          SNP ID column (optional, default auto-generate chr:pos)
  --gene-col NAME         Gene name column (optional)
  --slope-col NAME        Effect/Beta column (optional, for colour encoding)
  --effect-col NAME       Same as --slope-col

Rasterization options:
  Default:                auto-enable (>100k points)
  --no-raster             Disable rasterization
  --force-raster          Force rasterization
  --raster-width N        Grid size (default: 2000)

Style options:
  --no-background         No chromosome background bands

New in v2.1:
  Supports chr prefix (chr1, chr2, chrX etc.)
  Supports sex chromosomes (X, Y, MT)
  Effect/Slope column optional (P-value colouring if absent)
  SNP ID auto-generated (chr:pos format)
  Enhanced error handling

Examples:

  # Basic usage (auto SNP ID, P-value colouring)
  Rscript plot_trans_eqtl_manhattan_v2_enhanced.R data.txt
  
  # Use effect colouring
  Rscript plot_trans_eqtl_manhattan_v2_enhanced.R data.txt \\
    --slope-col beta
  
  # Full parameters (supports chr prefix)
  Rscript plot_trans_eqtl_manhattan_v2_enhanced.R data.txt \\
    --chr-col chr --pos-col pos --p-col pvalue \\
    --slope-col effect \\
    --gene-chr-col gene_chr --gene-start-col start --gene-end-col end

")
}

# ============================================================================
# Main function
# ============================================================================

.trans_main <- function() {
  cat("=============================================================================\n")
  cat("Trans-eQTL Manhattan plot tool (enhanced v2.1)\n")
  cat("=============================================================================\n")
  
  # Parse arguments
  args <- commandArgs(trailingOnly = TRUE)
  params <- .trans_parse_args(args)

  # Colour scheme mapping: scheme → color_low/color_high (only when not explicitly specified)
  TRANS_GRADIENTS <- list(
    classic    = list(low = "#4169E1", high = "#FFA500"),
    modern     = list(low = "#2E86AB", high = "#A23B72"),
    colorblind = list(low = "#0173B2", high = "#DE8F05"),
    pastel     = list(low = "#AEC6CF", high = "#FFB347"),
    vibrant    = list(low = "#4ECDC4", high = "#FF6B6B"),
    gray       = list(low = "#808080", high = "#D3D3D3")
  )
  if (!is.null(params$color_scheme) && params$color_scheme %in% names(TRANS_GRADIENTS)) {
    g <- TRANS_GRADIENTS[[params$color_scheme]]
    if (params$color_low  == "blue") params$color_low  <- g$low
    if (params$color_high == "red")  params$color_high <- g$high
  }

  cat(sprintf("\nInput file: %s\n", params$input_file))
  cat(sprintf("Output file: %s\n", params$output_file))
  
  # Check rasterization availability
  cat("\nChecking rasterization...\n")
  raster_status <- .check_rasterization_pkg()
  if(raster_status$available) {
    cat(sprintf("✓ %s\n", raster_status$message))
  } else {
    cat(sprintf("✗ %s\n", raster_status$message))
    cat("Will use standard plot\n")
  }
  
  # Reading data
  cat("\nReading data...\n")
  start_time <- Sys.time()
  
  data_raw <- fread(params$input_file, showProgress = TRUE)
  
  elapsed <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
  cat(sprintf("Read complete: %s rows (%.1f seconds)\n", 
              format(nrow(data_raw), big.mark = ","), elapsed))
  
  # Prepare data
  prep_result <- prepare_trans_eqtl_data(
    data_raw,
    chr_col = params$chr_col,
    pos_col = params$pos_col,
    p_col = params$p_col,
    gene_chr_col = params$gene_chr_col,
    gene_start_col = params$gene_start_col,
    gene_end_col = params$gene_end_col,
    snp_col = params$snp_col,
    gene_col = params$gene_col,
    slope_col = params$slope_col
  )
  
  data <- prep_result$data
  
  # Decide rasterization strategy
  cat("\n=== Rasterization strategy ===\n")
  cat(sprintf("Data points: %s\n", format(nrow(data), big.mark = ",")))
  
  if(params$raster_method == "auto") {
    decision <- .decide_rasterization(
      nrow(data),
      params$force_raster,
      params$no_raster,
      "basic"
    )
    params$raster_method <- decision$method
    cat(sprintf("Decision: %s\n", decision$reason))
  }
  
  use_raster <- params$raster_method != "standard" && 
                params$raster_method != "off" && 
                !params$no_raster
  
  if(use_raster && !raster_status$available) {
    cat("\nWarning: rasterization not available, falling back to standard plot\n")
    use_raster <- FALSE
  }
  
  # Plot
  if(use_raster) {
    p <- plot_trans_manhattan_rasterized(
      data, 
      prep_result$snp_chr_info, 
      prep_result$gene_chr_info, 
      params
    )
  } else {
    p <- plot_trans_manhattan_standard(
      data, 
      prep_result$snp_chr_info, 
      prep_result$gene_chr_info, 
      params
    )
  }
  
  # Save
  cat(sprintf("\nSaving plot: %s\n", params$output_file))
  start_time <- Sys.time()
  
  ggsave(
    params$output_file,
    plot = p,
    width = params$width,
    height = params$height,
    dpi = params$dpi,
    units = "in"
  )
  
  elapsed <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
  cat(sprintf("Save complete (%.1f seconds)\n", elapsed))
  
  cat("\n✓ Done!\n")
  cat(sprintf("\nSummary:\n"))
  cat(sprintf("  Total data points: %s\n", format(nrow(data), big.mark = ",")))
  cat(sprintf("  SNP chromosomes: %d\n", length(unique(prep_result$snp_chr_info$CHR))))
  cat(sprintf("  Gene chromosomes: %d\n", length(unique(prep_result$gene_chr_info$GENE_CHR))))
  if(prep_result$has_slope) {
    cat("  Colour encoding: Effect/Slope (gradient)\n")
  } else {
    cat("  Colour encoding: P-value (viridis)\n")
  }
  cat("=============================================================================\n")
}

# (CLI entry point is plot_trans_eqtl_cli() below)

#' Trans-eQTL Manhattan plot command-line interface
#'
#' Run as: \code{Rscript -e "RasterMan::plot_trans_eqtl_cli()" mydata.txt}
#'
#' Or via the installed script \code{plot_trans_eqtl.R} in
#' \code{system.file("scripts", package = "RasterMan")}.
#'
#' @export
plot_trans_eqtl_cli <- function() .trans_main()

# ============================================================================
# Short-name aliases
# ============================================================================

#' @rdname prepare_trans_eqtl_data
#' @export
prep_trans <- prepare_trans_eqtl_data

#' @rdname plot_trans_manhattan_rasterized
#' @export
plot_trans <- plot_trans_manhattan_rasterized
