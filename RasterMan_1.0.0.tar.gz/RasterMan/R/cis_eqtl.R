# ============================================================================
# RasterMan - Cis-eQTL Manhattan Plot Module
# ============================================================================

#' @importFrom ggplot2 ggplot aes geom_point geom_hline geom_rect geom_text
#'   scale_x_continuous scale_y_continuous scale_color_manual scale_color_gradient2
#'   theme_classic theme element_blank element_text labs ggsave coord_cartesian
#' @importFrom dplyr filter mutate group_by summarise arrange ungroup left_join
#'   select do n slice_head slice_max
#' @importFrom magrittr %>%
#' @importFrom data.table fread
NULL

# Package-aware rasterization check (replaces sourceCpp-based check_rasterization)
.check_rasterization_pkg <- function() {
  required <- c("rasterize_smart", "rasterize_multilevel",
                "rasterize_adaptive_density", "rasterize_basic",
                "analyze_data_distribution")
  available <- all(vapply(required, existsMethod_safe, logical(1)))
  if (available)
    list(available = TRUE,  message = "Rasterization functions loaded")
  else
    list(available = FALSE, message = "C++ rasterization module not compiled")
}

#' @export
fast_read_any <- function(file, chr_col, bp_col, gene_col, p_col, snp_col = NULL, showProgress = TRUE) {
  header <- names(data.table::fread(file, nrows = 0, showProgress = FALSE))
  
  # Parse column names
  chr_real  <- .resolve_col(header, chr_col)
  bp_real   <- .resolve_col(header, bp_col)
  gene_real <- .resolve_col(header, gene_col)
  p_real    <- .resolve_col(header, p_col)
  
  # SNP col: only search if explicitly specified
  snp_real  <- NULL
  if (!is.null(snp_col) && nzchar(snp_col)) {
    tryCatch({
      snp_real <- .resolve_col(header, snp_col)
      cat(sprintf("SNP column found: %s\n", snp_real))
    }, error = function(e) {
      cat(sprintf("SNP column '%s' not found, will generate chr:pos format\n", snp_col))
      snp_real <<- NULL
    })
  } else {
    cat("SNP column not specified, will generate chr:pos format\n")
  }

  need <- unique(na.omit(c(chr_real, bp_real, gene_real, p_real, snp_real)))
  cat(sprintf("Reading only columns: %s\n", paste(need, collapse = ", ")))

  # Key: fix types at read time to avoid full-column as.numeric/as.integer later
  # Note: CHR read as character to support "chr1", "X", "Y" etc.
  cc <- c(
    setNames("character", chr_real),  # CHR as character
    setNames("integer", bp_real),
    setNames("numeric",  p_real),
    setNames("character", gene_real)
  )
  if (!is.null(snp_real)) {
    cc <- c(cc, setNames("character", snp_real))
  }

  dt <- data.table::fread(
    file,
    select = need,
    colClasses = cc,
    sep = "\t",          # tab-delimited file, don't let fread guess
    quote = "",
    fill = TRUE,
    showProgress = showProgress
  )

  data.table::setDT(dt)
  data.table::setnames(dt, chr_real,  "CHR")
  data.table::setnames(dt, bp_real,   "BP")
  data.table::setnames(dt, gene_real, "Gene")
  data.table::setnames(dt, p_real,    "P")
  if (!is.null(snp_real)) {
    data.table::setnames(dt, snp_real, "SNP")
  }

  dt
}




# ============================================================================
# Rasterization capability detection and loading
# ============================================================================

.check_rasterization_orig <- function() {
  # Check if C++ rasterization functions are available
  required_funcs <- c("rasterize_smart", "rasterize_multilevel", 
                     "rasterize_adaptive_density", "rasterize_basic",
                     "analyze_data_distribution")
  
  available <- sapply(required_funcs, exists)
  
  if(all(available)) {
    return(list(available = TRUE, message = "Rasterization functions loaded"))
  }
  
  # Try loading C++ module
  cpp_file <- "gwas_smart_rasterization.cpp"
  if(file.exists(cpp_file)) {
    tryCatch({
      suppressMessages(Rcpp::sourceCpp(cpp_file))
      available <- sapply(required_funcs, exists)
      if(all(available)) {
        return(list(available = TRUE, message = "Loaded from gwas_smart_rasterization.cpp"))
      }
    }, error = function(e) {
      return(list(available = FALSE, message = sprintf("Load failed: %s", e$message)))
    })
  }
  
  return(list(available = FALSE, 
              message = "Rasterization not available\nHint: place gwas_smart_rasterization.cpp in the working directory"))
}

#' @export
prepare_cis_eqtl_manhattan_data <- function(gwas, gene_col = "Gene", chr_col = "CHR", bp_col = "BP", p_col = "P", snp_col = NULL) {
  cat("\n=== Data preparation (fast) ===\n")
  data.table::setDT(gwas)

  # ---------- 1) Validate column names (fast_read_any already standardised to CHR, BP, P, Gene, SNP) ----------
  # Note: fast_read_any() already standardised column names; just validate here
  required_cols <- c("CHR", "BP", "P", "Gene")
  missing_cols <- setdiff(required_cols, names(gwas))
  if (length(missing_cols) > 0) {
    stop(sprintf("Missing required columns: %s\nHint: fast_read_any should have already standardised column names",
                 paste(missing_cols, collapse = ", ")))
  }

  # SNP column: if absent, mark for generation (chr:pos format)
  if (!("SNP" %in% names(gwas))) {
    # Defer generation until after filtering to avoid paste0 on large rows
    gwas[, SNP := NA_character_]
  }

  # ---------- 2) Validate LOG10P exists (read_data already normalised, filtered, computed LOG10P) ----------
  if (!"LOG10P" %in% names(gwas)) {
    # Compatibility: compute LOG10P if read_data was not used
    cat("  LOG10P column not found, computing automatically...\n")
    if (!is.numeric(gwas$P)) gwas[, P := suppressWarnings(as.numeric(P))]
    gwas <- gwas[!is.na(P) & P > 0 & P <= 1]
    gwas[, LOG10P := as.single(-log10(P))]
  }
  if (!"CHR_label" %in% names(gwas))
    gwas[, CHR_label := as.character(CHR)]
  if (!is.integer(gwas$CHR))  gwas[, CHR := suppressWarnings(as.integer(CHR))]
  if (!is.integer(gwas$BP))   gwas[, BP  := suppressWarnings(as.integer(BP))]

  n_valid <- nrow(gwas)
  cat(sprintf("Valid rows: %s\n", format(n_valid, big.mark = ",")))
  if (n_valid == 0L) stop("Data is empty. Please call read_data() first.")

  # SNP: generate after filtering (format: chr:pos), using original labels X/Y/MT
  if (all(is.na(gwas$SNP))) {
    cat("Generating SNP IDs (format: chr:pos)...\n")
    gwas[, SNP := paste0(CHR_label, ":", BP)]
  }

  # ---------- 4) Summary stats (avoid slow unique(sort())) ----------
  cat(sprintf("Gene count: %s\n", format(data.table::uniqueN(gwas$Gene), big.mark = ",")))
  n_chr <- data.table::uniqueN(gwas$CHR)
  cat(sprintf("Chromosome count: %d\n", n_chr))

  if (n_chr > 30) {
    cat(sprintf("\nNote: many chromosomes (%d). Common in animal/plant genomes.\n", n_chr))
    cat("      Consider conservative raster grid limits to reduce memory.\n")
  }

  # ---------- 5) Compute cumulative positions (data.table, avoids dplyr join copy) ----------
cat("\nComputing cumulative positions...\n")

# Compute chr_len first; retain first CHR_label for display
chr_info <- gwas[, .(
  chr_len = max(BP, na.rm = TRUE),
  chr_label = first(CHR_label)  # retain original label for display
), by = CHR]
data.table::setorder(chr_info, CHR)

# Key: convert chr_len to double to avoid cumsum integer overflow
chr_info[, chr_len := as.numeric(chr_len)]

# cumsum uses numeric throughout
chr_info[, cumsum_start := data.table::shift(cumsum(chr_len), fill = 0)]
chr_info[, cumsum_end   := cumsum_start + chr_len]
chr_info[, chr_center   := cumsum_start + chr_len / 2]

# join back (BP_cumulative is numeric, handles up to 2.8e9)
data.table::setkey(chr_info, CHR)
data.table::setkey(gwas, CHR)
gwas[chr_info, BP_cumulative := as.numeric(BP) + i.cumsum_start]

cat(sprintf("Cumulative position range: %s - %s\n",
            format(min(gwas$BP_cumulative, na.rm = TRUE), big.mark = ","),
            format(max(gwas$BP_cumulative, na.rm = TRUE), big.mark = ",")))

  # ---------- 6) Single-precision output (for C++ rasterization, does not affect ggplot) ----------
  # base R has no true float vector; as.single returns float-tagged numeric passable to C++
  # If C++ already casts to float, these lines are optional.
  x_f <- as.numeric(gwas$BP_cumulative)
  y_f <- as.numeric(gwas$LOG10P)

  return(list(gwas = gwas, chr_info = chr_info, x = x_f, y = y_f))
}

######Identify Lead SNPs
identify_cis_lead_snps <- function(gwas, top_n = 1, min_logp = 5, force_include_genes = NULL) {
  cat("\n=== Identify Lead SNPs ===\n")

  # LOG10P should have been computed by read_data(); give a friendly error if missing
  if (!"LOG10P" %in% names(gwas))
    stop("Missing LOG10P column. Please call read_data() first.")
  # Guard: if Gene column not found
  if (!"Gene" %in% names(gwas))
    stop("identify_cis_lead_snps: Gene column missing from data frame; check column names or call fast_read_any() first")

  # Identify lead SNPs using standard criteria
  lead_snps <- gwas %>%
    filter(LOG10P >= min_logp) %>%
    group_by(Gene) %>%
    arrange(desc(LOG10P)) %>%
    slice_head(n = top_n) %>%
    ungroup()
  
  # Force-include specified genes (bypass min_logp filter)
  if(!is.null(force_include_genes) && length(force_include_genes) > 0) {
    cat(sprintf("\nForce-include genes: %d\n", length(force_include_genes)))
    
    # Find force-include genes not yet in lead_snps
    missing_genes <- setdiff(force_include_genes, lead_snps$Gene)
    
    if(length(missing_genes) > 0) {
      cat(sprintf("Genes to add: %d  (−log10(P) < %.1f）\n", 
                  length(missing_genes), min_logp))
      
      # Extract lead SNP for these genes from gwas
      forced_snps <- gwas %>%
        filter(Gene %in% missing_genes) %>%
        group_by(Gene) %>%
        arrange(desc(LOG10P)) %>%
        slice_head(n = top_n) %>%
        ungroup()
      
      if(nrow(forced_snps) > 0) {
        # Merge
        lead_snps <- bind_rows(lead_snps, forced_snps)
        cat(sprintf("Added %d  genes (−log10(P) range: %.2f - %.2f）\n",
                    nrow(forced_snps),
                    min(forced_snps$LOG10P),
                    max(forced_snps$LOG10P)))
      }
      
      # Check for genes absent from data
      found_genes <- unique(forced_snps$Gene)
      not_found <- setdiff(missing_genes, found_genes)
      if(length(not_found) > 0) {
        cat(sprintf("Warning: %d  genes not found in data\n", length(not_found)))
        if(length(not_found) <= 10) {
          cat(sprintf("  Missing genes: %s\n", paste(not_found, collapse = ", ")))
        }
      }
    }
  }
  
  cat(sprintf("\nGenes with significant associations: %s / %s\n", 
              format(length(unique(lead_snps$Gene)), big.mark = ","),
              format(length(unique(gwas$Gene)), big.mark = ",")))
  cat(sprintf("Lead SNPs: %s\n", format(nrow(lead_snps), big.mark = ",")))
  
  if(nrow(lead_snps) > 0) {
    cat(sprintf("-log10(P) range: %.2f - %.2f\n",
                min(lead_snps$LOG10P), max(lead_snps$LOG10P)))
  }
  
  return(lead_snps)
}

#' Read cis-eGene list file
read_cis_egene_list <- function(file_path) {
  cat("\n=== Read cis-eGene list ===\n")
  cat(sprintf("File: %s\n", file_path))
  
  if(!file.exists(file_path)) {
    cat(sprintf("Warning: file not found: %s\n", file_path))
    return(NULL)
  }
  
  # Try reading file (multiple formats supported)
  tryCatch({
    # Read first line to detect header
    first_line <- readLines(file_path, n = 1)
    
    # Single column: read directly
    if(!grepl("\t|,", first_line)) {
      genes <- readLines(file_path)
      genes <- genes[genes != ""]  # remove empty lines
    } else {
      # Multiple columns: try to find gene column
      df <- read.table(file_path, header = TRUE, stringsAsFactors = FALSE, 
                      sep = "\t", comment.char = "")
      
      # Search for gene column (common names)
      gene_col <- NULL
      possible_names <- c("Gene", "gene", "GENE", "gene_id", "gene_name", 
                         "GeneID", "GeneName")
      for(name in possible_names) {
        if(name %in% colnames(df)) {
          gene_col <- name
          break
        }
      }
      
      if(is.null(gene_col)) {
        # Use first column
        genes <- df[[1]]
        cat("Warning: no standard gene column found, using first column\n")
      } else {
        genes <- df[[gene_col]]
      }
    }
    
    # Deduplicate
    genes <- unique(genes)
    genes <- genes[!is.na(genes) & genes != ""]
    
    cat(sprintf("Read %s  genes\n", format(length(genes), big.mark = ",")))
    
    return(genes)
    
  }, error = function(e) {
    cat(sprintf("Error reading file: %s\n", e$message))
    return(NULL)
  })
}

# ============================================================================
# Rasterization strategy decision
# ============================================================================

.decide_rasterization_cis <- function(n_points, n_chr, force_raster, no_raster, method) {
  if(no_raster) {
    return(list(use = FALSE, method = "standard", 
                reason = "rasterization disabled by user"))
  }
  
  if(force_raster) {
    return(list(use = TRUE, method = method, 
                reason = "rasterization forced by user"))
  }
  
  # Special handling: many-chromosome data (>30)
  # e.g. pig 39 chromosomes, cattle 30 chromosomes
  # multilevel uses too much memory with many chromosomes; prefer smart
  if(n_chr > 30) {
    if(n_points > 10000000) {
      # Very large data: use basic (speed priority)
      return(list(use = TRUE, method = "basic",
                  reason = sprintf("Many-chromosome very-large data (%d chromosomes, %s points), using basic for speed", 
                                  n_chr, format(n_points, big.mark = ","))))
    } else if(n_points > 1000000) {
      # Large data: use smart (balance quality and memory)
      return(list(use = TRUE, method = "smart",
                  reason = sprintf("Many-chromosome data (%d chromosomes, %s points), using smart to avoid multilevel memory overflow", 
                                  n_chr, format(n_points, big.mark = ","))))
    }
    # Medium data: continue normal flow
  }
  
  # Auto decision (standard chromosome count)
  if(n_points < 100000) {
    return(list(use = FALSE, method = "standard",
                reason = sprintf("Small dataset (%s points), using standard plot", 
                                format(n_points, big.mark = ","))))
  } else if(n_points < 1000000) {
    return(list(use = TRUE, method = "smart",
                reason = sprintf("Medium dataset (%s points), using smart rasterization", 
                                format(n_points, big.mark = ","))))
  } else if(n_points < 5000000) {
    return(list(use = TRUE, method = "multilevel",
                reason = sprintf("Large dataset (%s points), using multilevel rasterization", 
                                format(n_points, big.mark = ","))))
  } else {
    # Very large data: choose method based on chromosome count
    if(n_chr > 25) {
      # Many chromosomes: prefer smart (avoid multilevel memory issues)
      return(list(use = TRUE, method = "smart",
                  reason = sprintf("Large data (%s points, %d chromosomes), using smart to avoid memory issues", 
                                  format(n_points, big.mark = ","), n_chr)))
    } else {
      return(list(use = TRUE, method = "multilevel",
                  reason = sprintf("Very large data (%s points), using multilevel rasterization", 
                                  format(n_points, big.mark = ","))))
    }
  }
}

# ============================================================================
# Plot function (standard)
# ============================================================================

# ============================================================================

#' @export
plot_manhattan_rasterized <- function(gwas, chr_info, params, lead_snps = NULL, highlight_genes = NULL) {
  # raster_method: "basic" / "smart" / "adaptive" / "multilevel" (rasterized) or "off" (direct ggplot)
  raster_method <- if (!is.null(params$raster_method)) params$raster_method else "basic"
  if (!raster_method %in% c("basic", "smart", "adaptive", "multilevel", "off"))
    stop(sprintf("raster_method must be one of 'basic'/'smart'/'adaptive'/'multilevel'/'off', got: '%s'", raster_method))

  # Resolve color scheme
  chr_colors <- resolve_color_scheme(params$color_scheme, params$color_even, params$color_odd)

  # ── Auto-prepare: call prepare_cis_eqtl_manhattan_data() if BP_cumulative absent ──
  if (!"BP_cumulative" %in% names(gwas)) {
    cat("BP_cumulative column not found，auto-calling prepare_cis_eqtl_manhattan_data()...\n")
    if (!all(c("CHR", "BP", "P", "Gene") %in% names(gwas)))
      stop("gwas Missing required columns（CHR/BP/P/Gene），Please call first fast_read_any() Reading data")
    prep <- prepare_cis_eqtl_manhattan_data(
      gwas,
      gene_col = "Gene",
      chr_col  = if (!is.null(params$chr_col))  params$chr_col  else "CHR",
      bp_col   = if (!is.null(params$bp_col))   params$bp_col   else "BP",
      p_col    = if (!is.null(params$p_col))    params$p_col    else "P",
      snp_col  = if (!is.null(params$snp_col))  params$snp_col  else NULL
    )
    gwas     <- prep$gwas
    chr_info <- prep$chr_info
  }

  # ── raster_method = "off": standard direct plot (no C++) ────────────────────
  if (raster_method == "off") {
    cat("\n=== Plotting (standard, no rasterization) ===\n")
    gwas <- gwas %>%
      mutate(
        CHR_color    = ifelse(CHR %% 2 == 0, "even", "odd"),
        is_highlight = if (!is.null(highlight_genes)) Gene %in% highlight_genes else FALSE
      )
    if (!is.null(highlight_genes)) {
      n_hl <- length(unique(gwas$Gene[gwas$is_highlight]))
      cat(sprintf("Highlight genes: %d / %d  genesfound in data\n", n_hl, length(highlight_genes)))
    }
    p <- ggplot(gwas, aes(x = BP_cumulative, y = LOG10P)) +
      theme_classic() +
      theme(
        plot.title = element_text(size = 14, hjust = 0.5, face = "bold"),
        axis.title = element_text(size = 12, face = "bold"),
        axis.text  = element_text(size = 10),
        legend.position = "none",
        panel.border = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.y = element_line(color = "gray90", linewidth = 0.3)
      ) +
      labs(x = "Chromosome", y = expression(-log[10](italic(P))))
    if (isTRUE(params$chr_background)) {
      y_max  <- max(gwas$LOG10P, na.rm = TRUE)
      band_h <- max(min(y_max * 0.02, 1.0), 0.15)
      band_df <- transform(chr_info,
        ymin = -band_h, ymax = 0,
        fill = ifelse(seq_len(nrow(chr_info)) %% 2 == 0, "grey92", "white"))
      p <- p +
        geom_rect(data = band_df, inherit.aes = FALSE,
          aes(xmin = cumsum_start, xmax = cumsum_end, ymin = ymin, ymax = ymax, fill = fill),
          alpha = 1) +
        scale_fill_identity() +
        coord_cartesian(ylim = c(-band_h, y_max * 1.02))
    }
    gwas_normal    <- gwas %>% filter(!is_highlight)
    gwas_highlight <- gwas %>% filter(is_highlight)
    if (nrow(gwas_normal) > 0)
      p <- p + geom_point(data = gwas_normal, aes(color = CHR_color),
                          size = params$point_size, alpha = 0.8)
    if (nrow(gwas_highlight) > 0)
      p <- p + geom_point(data = gwas_highlight,
                          color = params$highlight_color, size = params$highlight_size, alpha = 0.9)
    p <- p + scale_color_manual(values = chr_colors)
    if (isTRUE(params$show_sig_line) && is.finite(params$sig_line_p) &&
        params$sig_line_p > 0 && params$sig_line_p < 1)
      p <- p + geom_hline(yintercept = -log10(params$sig_line_p),
                          linetype = "dashed", color = "red", linewidth = 0.8)
    p <- p + scale_x_continuous(breaks = chr_info$chr_center, labels = chr_info$chr_label,
                                 expand = c(0.01, 0), guide = guide_axis(check.overlap = TRUE))
    if (!is.null(lead_snps) && nrow(lead_snps) > 0) {
      lead_snps <- lead_snps %>%
        group_by(Gene) %>% slice_max(order_by = LOG10P, n = 1, with_ties = FALSE) %>%
        ungroup() %>% arrange(desc(LOG10P))
      maxL <- params$max_labels
      if (!is.null(maxL) && is.finite(maxL) && maxL > 0) {
        if (!is.null(highlight_genes) && length(highlight_genes) > 0)
          lead_snps <- lead_snps %>%
            mutate(is_highlight = Gene %in% highlight_genes) %>%
            arrange(desc(is_highlight), desc(LOG10P), Gene) %>%
            slice_head(n = as.integer(maxL))
        else
          lead_snps <- lead_snps %>% arrange(desc(LOG10P), Gene) %>% slice_head(n = as.integer(maxL))
      }
      cat(sprintf("Annotate %d  genes\n", nrow(lead_snps)))
      if (!is.null(highlight_genes) && "is_highlight" %in% colnames(lead_snps)) {
        lead_hl  <- lead_snps %>% filter(is_highlight)
        lead_nor <- lead_snps %>% filter(!is_highlight)
        if (nrow(lead_nor) > 0)
          p <- p + geom_text_repel(data = lead_nor,
            aes(x = BP_cumulative, y = LOG10P, label = Gene),
            size = params$label_size, max.overlaps = 20,
            segment.linewidth = 0.2, segment.color = "gray40", min.segment.length = 0)
        if (nrow(lead_hl) > 0)
          p <- p + geom_text_repel(data = lead_hl,
            aes(x = BP_cumulative, y = LOG10P, label = Gene),
            size = params$label_size + 0.5, fontface = "bold",
            color = params$highlight_color, max.overlaps = 20,
            segment.linewidth = 0.3, segment.color = params$highlight_color,
            min.segment.length = 0)
      } else {
        p <- p + geom_text_repel(data = lead_snps,
          aes(x = BP_cumulative, y = LOG10P, label = Gene),
          size = params$label_size, max.overlaps = 20,
          segment.linewidth = 0.2, segment.color = "gray40", min.segment.length = 0)
      }
    }
    return(p)
  }

  # ── raster_method rasterized plot (basic/smart/adaptive/multilevel) ────────────
  cat("\n=== Plotting (rasterized) ===\n")
  cat(sprintf("Rasterization method: %s\n", raster_method))
  

  
  # Save highlight genes raw data (before rasterization)
  gwas_highlight <- NULL
  if(!is.null(highlight_genes)) {
    gwas_highlight <- gwas %>%
      filter(Gene %in% highlight_genes)
    
    if(nrow(gwas_highlight) > 0) {
      n_highlight_genes <- length(unique(gwas_highlight$Gene))
      cat(sprintf("Highlight genes: %d / %d  genesfound in data\n", 
                  n_highlight_genes, length(highlight_genes)))
      cat(sprintf("Highlight points: %s (will be overlaid after rasterization)\n", 
                  format(nrow(gwas_highlight), big.mark = ",")))
    } else {
      gwas_highlight <- NULL
    }
  }
  
  # Prepare rasterization data
  x <- gwas$BP_cumulative
  y <- gwas$LOG10P
  colors_int <- as.integer(factor(gwas$CHR))
  p_values <- gwas$P
  n_colors <- length(unique(colors_int))
  
  xmin <- min(x, na.rm = TRUE)
  xmax <- max(x, na.rm = TRUE)
  ymin <- 0
  ymax <- max(y, na.rm = TRUE) * 1.05
  
  cat(sprintf("Input data: %s points\n", format(length(x), big.mark = ",")))
  
  # Determine grid size
  if(is.null(params$raster_width) || is.null(params$raster_height)) {
    raster_width  <- 2000L
    raster_height <- 1000L
    
    # Safety limits to prevent OOM
    # Tighter limits for many-chromosome data (e.g. animal genomes)
    if(n_colors > 30) {
      max_width <- 2000
      max_height <- 800
      max_cells <- 1000000  # 1M cell limit
      cat(sprintf("Detected%d chromosomes (non-human data), using conservative grid limits\n", n_colors))
    } else {
      max_width <- 3000
      max_height <- 1500
      max_cells <- 2000000  # 2M cell limit
    }
    
    if(raster_width > max_width) {
      cat(sprintf("Warning: grid width too large (%d)), capping at %d\n", raster_width, max_width))
      raster_width <- max_width
    }
    if(raster_height > max_height) {
      cat(sprintf("Warning: grid height too large (%d)), capping at %d\n", raster_height, max_height))
      raster_height <- max_height
    }
    
    total_cells <- raster_width * raster_height
    if(total_cells > max_cells) {
      scale_factor <- sqrt(max_cells / total_cells)
      raster_width <- as.integer(raster_width * scale_factor)
      raster_height <- as.integer(raster_height * scale_factor)
      cat(sprintf("Warning: grid too large, scaled to %d x %d (total cells: %d)\n", 
                  raster_width, raster_height, raster_width * raster_height))
    }
    
    cat(sprintf("Recommended grid: %d x %d (total cells: %s)\n", 
                raster_width, raster_height, 
                format(raster_width * raster_height, big.mark = ",")))
  } else {
    raster_width <- params$raster_width
    raster_height <- params$raster_height
    cat(sprintf("Using specified grid: %d x %d\n", raster_width, raster_height))
  }
  
  # Run rasterization
  cat("\nRun rasterization...\n")
  sig_threshold_logp <- -log10(params$sig_threshold)

  # Resolve C++ functions from package namespace (.onLoad ensures they are present)
  .get_cpp_fn <- function(nm) {
    fn <- tryCatch(get(nm, envir = asNamespace("RasterMan"), inherits = FALSE),
                   error = function(e) NULL)
    if (!is.null(fn)) return(fn)
    stop(paste0(
      "C++ function '", nm, "' not available.\n",
      "Try reinstalling from source:\n",
      "  install.packages('RasterMan_1.0.0.tar.gz', repos=NULL, type='source')"
    ))
  }
  .rasterize_smart    <- .get_cpp_fn("rasterize_smart")
  .rasterize_multi    <- .get_cpp_fn("rasterize_multilevel")
  .rasterize_adaptive <- .get_cpp_fn("rasterize_adaptive_density")
  .rasterize_basic    <- .get_cpp_fn("rasterize_basic")

  start_time <- Sys.time()

  result <- tryCatch({
    if (raster_method == "smart") {
      .rasterize_smart(
        x, y, colors_int,
        raster_width, raster_height,
        xmin, xmax, ymin, ymax,
        n_colors, sig_threshold_logp, TRUE
      )
    } else if (raster_method == "multilevel") {
      if (n_colors > 30) {
        fine_w  <- min(2000L, raster_width);  fine_h  <- min(800L, raster_height)
        coarse_w <- as.integer(fine_w * 0.4); coarse_h <- as.integer(fine_h * 0.4)
        cat(sprintf("Detected%d chromosomes, using conservative multilevel grid: fine %dx%d coarse %dx%d\n",
                    n_colors, fine_w, fine_h, coarse_w, coarse_h))
      } else {
        fine_w <- raster_width; fine_h <- raster_height
        coarse_w <- as.integer(raster_width * 0.5); coarse_h <- as.integer(raster_height * 0.5)
      }
      .rasterize_multi(
        x, y, colors_int, p_values,
        xmin, xmax, ymin, ymax, n_colors,
        coarse_w, coarse_h, fine_w, fine_h,
        params$sig_threshold
      )
    } else if (raster_method == "adaptive") {
      .rasterize_adaptive(
        x, y, colors_int,
        xmin, xmax, ymin, ymax, n_colors,
        raster_width, raster_height, 0.3
      )
    } else {
      # basic (default)
      .rasterize_basic(
        x, y, colors_int,
        raster_width, raster_height,
        xmin, xmax, ymin, ymax,
        n_colors
      )
    }
  }, error = function(e) {
    if (grepl("bad_alloc|cannot allocate", as.character(e))) {
      cat("\nMemory allocation failed, falling back to basic with smaller grid...\n")
      small_w <- as.integer(raster_width * 0.5)
      small_h <- as.integer(raster_height * 0.5)
      cat(sprintf("  Reduced grid: %d x %d\n", small_w, small_h))
      .rasterize_basic(x, y, colors_int, small_w, small_h, xmin, xmax, ymin, ymax, n_colors)
    } else {
      stop(e)
    }
  })
  
  elapsed <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
  
  cat(sprintf("Rasterization complete: %s -> %s points\n",
              format(result$n_input, big.mark = ","),
              format(result$n_output, big.mark = ",")))
  cat(sprintf("  Compression ratio: %.1f%% (retained %.2f%%)\n",
              100 * (1 - result$n_output / result$n_input),
              100 * result$n_output / result$n_input))
  cat(sprintf("  Elapsed time: %.2f  seconds\n", elapsed))
  
  # Build rasterized data frame
  raster_df <- data.frame(
    BP_cumulative = result$x,
    LOG10P = result$y,
    CHR_id = result$color
  )
  
  # Map back to chromosomes
  chr_map <- gwas %>%
    select(CHR) %>%
    distinct() %>%
    mutate(CHR_id = as.integer(factor(CHR)))
  
  raster_df <- raster_df %>%
    left_join(chr_map, by = "CHR_id") %>%
    mutate(CHR_color = ifelse(CHR %% 2 == 0, "even", "odd"))
  
  # Build plot
  p <- ggplot(raster_df, aes(x = BP_cumulative, y = LOG10P)) +
    theme_classic() +
    theme(
      plot.title = element_text(size = 14, hjust = 0.5, face = "bold"),
      axis.title = element_text(size = 12, face = "bold"),
      axis.text = element_text(size = 10),
      legend.position = "none",
      panel.border = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.grid.minor.x = element_blank(),
      panel.grid.major.y = element_line(color = "gray90", linewidth = 0.3)
    ) +
    labs(
      x = "Chromosome",
      y = expression(-log[10](italic(P))),
      #title = sprintf("%s (Rasterized: %s)", params$title, params$raster_method)
    )
# ---- Nature-style chromosome band at bottom (height proportional to panel) ----
if (isTRUE(params$chr_background)) {

  y_max  <- max(gwas$LOG10P, na.rm = TRUE)

  # Band height (proportional to y range)
  band_h <- y_max * 0.04
  band_h <- max(band_h, 0.15)   # lower bound, avoid invisible thin band
  band_h <- min(band_h, 1.0)    # upper bound, avoid too thick

  # geom_rect is cleaner and faster than looping annotate
  band_df <- transform(
    chr_info,
    ymin = -band_h,
    ymax = 0,
    fill = ifelse(seq_len(nrow(chr_info)) %% 2 == 0, "grey92", "white")
  )

  p <- p +
    geom_rect(
      data = band_df,
      inherit.aes = FALSE,
      aes(xmin = cumsum_start, xmax = cumsum_end, ymin = ymin, ymax = ymax, fill = fill),
      alpha = 1
    ) +
    scale_fill_identity()
  
  # Key: expand y lower limit by band height, otherwise band gets clipped
  p <- p + coord_cartesian(ylim = c(-band_h, y_max * 1.02))
}
  
  # Add data points (rasterized first, then overlay highlight)
  p <- p + 
    geom_point(aes(color = CHR_color), size = 0.8, alpha = 0.8) +
    scale_color_manual(values = chr_colors)
  
  # Overlay highlight genes raw data points
  if(!is.null(gwas_highlight) && nrow(gwas_highlight) > 0) {
    p <- p + 
      geom_point(data = gwas_highlight,
                 aes(x = BP_cumulative, y = LOG10P),
                 color = params$highlight_color,
                 size = params$highlight_size,
                 alpha = 0.9)
  }
  
  # Add significance threshold line
if (isTRUE(params$show_sig_line) && is.finite(params$sig_line_p) && params$sig_line_p > 0 && params$sig_line_p < 1) {
  p <- p + geom_hline(
    yintercept = -log10(params$sig_line_p),
    linetype = "dashed",
    color = "red",
    linewidth = 0.8
  )
}
  
  # Set X axis
  p <- p + 
    scale_x_continuous(
      breaks = chr_info$chr_center,
      labels = chr_info$chr_label,  # use original chromosome labels (X, Y, MT etc.)
      expand = c(0.01, 0),guide = guide_axis(check.overlap = TRUE)
    )
  
  # Add gene labels
  if(!is.null(lead_snps) && nrow(lead_snps) > 0) {
    # If highlight genes specified, prioritise labelling them
    if(!is.null(highlight_genes)) {
      lead_snps <- lead_snps %>%
        mutate(is_highlight = Gene %in% highlight_genes) %>%
        arrange(desc(is_highlight), desc(LOG10P))
    }
    
# ---- Label selection: deterministic (by significance) ----
if (!is.null(lead_snps) && nrow(lead_snps) > 0) {

  maxL <- params$max_labels
  if (!is.null(maxL) && is.finite(maxL) && maxL > 0) {

    # Global stable sort: LOG10P descending, Gene as tie-break
    lead_snps <- lead_snps %>%
      arrange(desc(LOG10P), Gene)

    if (!is.null(highlight_genes) && length(highlight_genes) > 0) {
      lead_snps <- lead_snps %>%
        mutate(is_highlight = Gene %in% highlight_genes) %>%
        arrange(desc(is_highlight), desc(LOG10P), Gene)

      # Highlight genes first, then fill by significance
      lead_snps <- lead_snps %>% slice_head(n = as.integer(maxL))
    } else {
      # No highlight: take top maxL by significance
      lead_snps <- lead_snps %>% slice_head(n = as.integer(maxL))
    }
  }
}
    
    cat(sprintf("\nAnnotate %d  genes\n", nrow(lead_snps)))
    
    # Label highlight and normal genes separately
    if(!is.null(highlight_genes) && "is_highlight" %in% colnames(lead_snps)) {
      lead_highlight <- lead_snps %>% filter(is_highlight)
      lead_normal <- lead_snps %>% filter(!is_highlight)
      
      # Label normal genes
      if(nrow(lead_normal) > 0) {
        p <- p + 
          geom_text_repel(
            data = lead_normal,
            aes(x = BP_cumulative, y = LOG10P, label = Gene),
            size = params$label_size,
            max.overlaps = 20,
            segment.linewidth = 0.2,
            segment.color = "gray40",
            min.segment.length = 0
          )
      }
      
      # Label highlight genes (bold, highlight colour)
      if(nrow(lead_highlight) > 0) {
        p <- p + 
          geom_text_repel(
            data = lead_highlight,
            aes(x = BP_cumulative, y = LOG10P, label = Gene),
            size = params$label_size + 0.5,
            fontface = "bold",
            color = params$highlight_color,
            max.overlaps = 20,
            segment.linewidth = 0.3,
            segment.color = params$highlight_color,
            min.segment.length = 0
          )
      }
    } else {
      # No highlight genes: use standard labelling
      p <- p + 
        geom_text_repel(
          data = lead_snps,
          aes(x = BP_cumulative, y = LOG10P, label = Gene),
          size = params$label_size,
          max.overlaps = 20,
          segment.linewidth = 0.2,
          segment.color = "gray40",
          min.segment.length = 0
        )
    }
  }
  
  return(p)
}

.cis_parse_args <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  
  if(length(args) == 0 || "--help" %in% args || "-h" %in% args) {
    .cis_print_help()
    quit(status = 0)
  }
  
  params <- list(
    input_file = args[1],
    output_file = "cis_eqtl_manhattan.png",
    # Column names
    chr_col = "Chr",
    bp_col = "Position",
    gene_col = "Gene",
    p_col = "Pvalue",
    snp_col = NULL,  # default NULL, will auto-generate chr:pos SNP IDs
    # Lead SNP parameters
    lead_snp_per_gene = 1,
    min_gene_logp = 5,
    max_labels = NULL,
    # Significance
    sig_threshold = 1e-5,
    # Plot parameters
    width = 14,
    height = 7,
    dpi = 300,
    #title = "Cis-eQTL Manhattan Plot",
    # Style parameters
    color_scheme = "modern",
    color_even   = NULL,
    color_odd    = NULL,
    point_size = 0.8,
    label_size = 3,
    chr_background = TRUE,
    # Rasterization parameters
    raster_method = "auto",
    raster_width = 2000L,
    raster_height = 1000L,
    force_raster = FALSE,
    no_raster = FALSE,
    # cis-eGene highlight parameters
    anno_cis_egene = NULL,
    highlight_color = "red",
    highlight_size = 1.5
  )
  
  i <- 2
  while(i <= length(args)) {
    arg <- args[i]
    
    if(arg == "-o" || arg == "--output") {
      params$output_file <- args[i+1]
      i <- i + 2
    } else if(arg == "--chr-col") {
      params$chr_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--bp-col") {
      params$bp_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--gene-col") {
      params$gene_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--p-col") {
      params$p_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--snp-col") {
      params$snp_col <- args[i+1]
      i <- i + 2
    } else if(arg == "--min-gene-logp") {
      params$min_gene_logp <- as.numeric(args[i+1])
      i <- i + 2
    } else if(arg == "--max-labels") {
      params$max_labels <- as.integer(args[i+1])
      i <- i + 2
    } else if(arg == "--sig-threshold") {
      params$sig_threshold <- as.numeric(args[i+1])
      i <- i + 2
    } else if(arg == "--width") {
      params$width <- as.numeric(args[i+1])
      i <- i + 2
    } else if(arg == "--height") {
      params$height <- as.numeric(args[i+1])
      i <- i + 2
    } else if(arg == "--dpi") {
      params$dpi <- as.integer(args[i+1])
      i <- i + 2
    } else if(arg == "--title") {
      params$title <- args[i+1]
      i <- i + 2
    } else if(arg == "--no-background") {
      params$chr_background <- FALSE
      i <- i + 1
    } else if(arg == "--raster-method") {
      params$raster_method <- args[i+1]
      i <- i + 2
    } else if(arg == "--raster-width") {
      params$raster_width <- as.integer(args[i+1])
      i <- i + 2
    } else if(arg == "--raster-height") {
      params$raster_height <- as.integer(args[i+1])
      i <- i + 2
    } else if(arg == "--force-raster") {
      params$force_raster <- TRUE
      i <- i + 1
    } else if(arg == "--no-raster") {
      params$no_raster <- TRUE
      i <- i + 1
    } else if(arg == "--anno-gene") {
      params$anno_cis_egene <- args[i+1]
      i <- i + 2
    } else if(arg == "--highlight-color") {
      params$highlight_color <- args[i+1]
      i <- i + 2
    } else if(arg == "--highlight-size") {
      params$highlight_size <- as.numeric(args[i+1])
      i <- i + 2
    } else if(arg == "--color-scheme") {
      params$color_scheme <- args[i+1]
      i <- i + 2
    } else if(arg == "--color-even") {
      params$color_even <- args[i+1]
      i <- i + 2
    } else if(arg == "--color-odd") {
      params$color_odd <- args[i+1]
      i <- i + 2
    } else {
      cat(sprintf("Warning: unknown argument '%s'\n", arg))
      i <- i + 1
    }
  }
  
  return(params)
}

.cis_print_help <- function() {
  cat("
Cis-eQTL Manhattan plot command-line tool (rasterized)

Usage:
  Rscript plot_cis_eqtl_manhattan.R <input_file> [options]

Required arguments:
  input_file              Input file (cis-eQTL results)

Output options:
  -o, --output FILE       Output filename (default: cis_eqtl_manhattan.png)
  --width INCHES          Plot width (default: 14)
  --height INCHES         Plot height (default: 7)
  --dpi DPI               Resolution (default: 300)
  --title TEXT            Plot title

Column name options:
  --chr-col NAME          Chromosome column (default: Chr)
  --bp-col NAME           Position column (default: Position)
  --gene-col NAME         Gene column (default: Gene)
  --p-col NAME            P-value column (default: Pvalue)
  --snp-col NAME          SNP ID column (default: NULL)
                          If not specified, SNP IDs are auto-generated as chr:pos

Lead SNP annotation options:
  --min-gene-logp VALUE   Minimum -log10(P) for gene labelling (default: 5)
  --max-labels N          Maximum genes to label (default: NULL)
  --sig-threshold VALUE   Significance threshold (default: 1e-5)

Cis-eGene highlight options:
  --anno-gene FILE        cis-eGene list file (one gene per line, or table with gene column)
                          These genes are highlighted (red, larger) and labelled preferentially
  --highlight-color COLOR Highlight colour (default: red)
  --highlight-size SIZE   Highlight point size (default: 1.5)

Rasterization options (large-data acceleration):
  Note: C++ rasterization uses majority vote to determine cell colour
      Suitable for: discrete colours (chromosome = colour)
      Not suitable for: continuous colours (effect value = colour)
      Cis-eQTL colours by chromosome by default, compatible with C++ strategy
  
  --raster-method METHOD  Rasterization method (default: auto)
                          auto      - auto-select (recommended)
                          smart     - smart rasterization (100k-1000k points)
                                     preserves significant signals, density-aware
                          multilevel- multi-level rasterization (1M+ points, recommended)
                                     high-res for significant points, low-res background
                          adaptive  - adaptive density rasterization
                                     subdivides high-density, simplifies low-density
                          basic     - basic rasterization
                                     fastest but may obscure weak signals
                          off       - disable rasterization
  
  --raster-width N        Grid width (default: auto)
  --raster-height N       Grid height (default: auto)
  --force-raster          Force rasterization
  --no-raster             Disable rasterization

Visual notes:
  All C++ rasterization strategies use majority vote for cell colour:
  Advantage: fast, suited for discrete colours (chromosome colouring)
  Limitation: gradient lost with continuous colour encoding (e.g. effect values)
  
  Performance vs quality trade-offs:
  multilevel: best balance (significant signals fully preserved)
  smart: high quality (adaptive sampling)
  basic: fastest (may obscure weak signals)

Style options:
  --no-background         No chromosome background bands

Examples:

  # Basic usage (auto rasterization)
  Rscript plot_cis_eqtl_manhattan.R data.txt
  
  # Large dataset (31M rows) - use multilevel
  Rscript plot_cis_eqtl_manhattan.R big_data.txt \\
    --raster-method multilevel \\
    --max-labels 50
  
  # Specify column names
  Rscript plot_cis_eqtl_manhattan.R Mangchang.gene.sign.top3.txt \\
    --chr-col Chr \\
    --bp-col Position \\
    --gene-col Gene \\
    --p-col Pvalue \\
    --raster-method multilevel
  
  # Custom grid size
  Rscript plot_cis_eqtl_manhattan.R data.txt \\
    --raster-method smart \\
    --raster-width 2000 \\
    --raster-height 1000
  
  # Highlight specific cis-eGenes
  Rscript plot_cis_eqtl_manhattan.R data.txt \\
    --anno-gene my_genes.txt \\
    --max-labels 50 \\
    --highlight-color red \\
    --highlight-size 2

Performance vs quality (31M data points):
  Method         Elapsed time  Quality   Memory    Recommendation
  -------------------------------------------------------
  no raster     ~30 min   100%      overflow  ⭐
  basic         ~2 min    85%       low       ⭐⭐⭐
  smart         ~1.5 min  92%       medium    ⭐⭐⭐⭐
  multilevel    ~1 min    95%       medium    ⭐⭐⭐⭐⭐ (recommended)
  adaptive      ~2.5 min  93%       high      ⭐⭐⭐⭐

  Notes:
  multilevel: significant signals fully preserved, background moderately compressed
  smart: density-aware, adaptive sampling, best balance
  basic: fastest but may obscure weak signals; suited for very large datasets
  adaptive: subdivides high-density regions; higher memory usage
  
  Note: all strategies use majority vote; suited for discrete colours (chromosomes)

")
}

# ============================================================================
# Main function
# ============================================================================

.cis_main <- function() {
  cat("=============================================================================\n")
  cat("Cis-eQTL Manhattan plot tool (rasterized)\n")
  cat("=============================================================================\n")
  
  # Parse arguments
  params <- .cis_parse_args()
  
  cat(sprintf("\nInput file: %s\n", params$input_file))
  cat(sprintf("Output file: %s\n", params$output_file))
  
  # Check rasterization availability
  cat("\nChecking rasterization...\n")
  raster_status <- .check_rasterization_pkg()
  cat(raster_status$message, "\n")
  
  # Reading data
  cat("\nReading data...\n")
  start_time <- Sys.time()
  
  if(grepl("\\.gz$", params$input_file)) {
    cat("Detected .gz compressed file, using fread for fast reading...\n")
cat("\nReading data...\n")
start_time <- Sys.time()

gwas_raw <- fast_read_any(
  file     = params$input_file,
  chr_col  = params$chr_col,
  bp_col   = params$bp_col,
  gene_col = params$gene_col,
  p_col    = params$p_col,
  snp_col  = params$snp_col,
  showProgress = TRUE
)

  } else {
    start_time <- Sys.time()
gwas_raw <- fast_read_any(
  file     = params$input_file,
  chr_col  = params$chr_col,
  bp_col   = params$bp_col,
  gene_col = params$gene_col,
  p_col    = params$p_col,
  snp_col  = params$snp_col,
  showProgress = TRUE
)


  }
  
  elapsed <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
  cat(sprintf("Read complete: %s rows (%.1f seconds)\n", 
              format(nrow(gwas_raw), big.mark = ","), elapsed))
  
  # Prepare data
  result <- prepare_cis_eqtl_manhattan_data(
    gwas_raw,
    gene_col = params$gene_col,
    chr_col = params$chr_col,
    bp_col = params$bp_col,
    p_col = params$p_col,
    snp_col = params$snp_col
  )
  
  gwas <- result$gwas
  chr_info <- result$chr_info
  
  # Read cis-eGene list (if provided)
  highlight_genes <- NULL
  if(!is.null(params$anno_cis_egene)) {
    highlight_genes <- read_cis_egene_list(params$anno_cis_egene)
  }
  
  # Identify lead SNPs (highlight genes are force-included regardless of min_logp)
  lead_snps <- identify_cis_lead_snps(
    gwas,
    top_n = params$lead_snp_per_gene,
    min_logp = params$min_gene_logp,
    force_include_genes = highlight_genes
  )
  
  # Decide rasterization strategy
  cat("\n=== Rasterization strategy ===\n")
  
  # Compute chromosome count
  n_chr <- length(unique(gwas$CHR))
  cat(sprintf("Data points: %s\n", format(nrow(gwas), big.mark = ",")))
  cat(sprintf("Chromosome count: %d\n", n_chr))
  
  if(params$raster_method == "auto") {
    decision <- .decide_rasterization_cis(
      nrow(gwas),
      n_chr,
      params$force_raster,
      params$no_raster,
      "smart"
    )
    params$raster_method <- decision$method
    cat(sprintf("Auto decision: %s\n", decision$reason))
  }
  
  use_raster <- params$raster_method != "standard" && 
                params$raster_method != "off" && 
                !params$no_raster
  
  if(use_raster && !raster_status$available) {
    cat("\nWarning: rasterization not available, falling back to standard plot\n")
    use_raster <- FALSE
  }
  
  # Plot
  if(use_raster) {
    p <- plot_manhattan_rasterized(gwas, chr_info, params, lead_snps, highlight_genes)
  } else {
    p <- plot_manhattan_standard(gwas, chr_info, params, lead_snps, highlight_genes)
  }
  
  # Save
  cat(sprintf("\nSaving plot: %s\n", params$output_file))
  start_time <- Sys.time()
  
  ggsave(
    params$output_file,
    plot = p,
    width = params$width,
    height = params$height,
    dpi = params$dpi,
    units = "in"
  )
  
  elapsed <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
  cat(sprintf("Save complete (%.1f seconds)\n", elapsed))
  
  cat("\n✓ Done!\n")
  cat(sprintf("\nSummary:\n"))
  cat(sprintf("  Total associations: %s\n", format(nrow(gwas), big.mark = ",")))
  cat(sprintf("  Gene count: %s\n", format(length(unique(gwas$Gene)), big.mark = ",")))
  cat(sprintf("  Significant genes: %s\n", format(length(unique(lead_snps$Gene)), big.mark = ",")))
  cat(sprintf("  Annotate genes: %s\n", format(nrow(lead_snps), big.mark = ",")))
  if(use_raster) {
    cat(sprintf("  Rasterization method: %s\n", params$raster_method))
  }
  cat("\n")
}

# (CLI entry point is plot_cis_eqtl_cli() below)

#' Cis-eQTL Manhattan plot command-line interface
#'
#' Run as: \code{Rscript -e "RasterMan::plot_cis_eqtl_cli()" mydata.txt}
#'
#' Or via the installed script \code{plot_cis_eqtl.R} in
#' \code{system.file("scripts", package = "RasterMan")}.
#'
#' @export
plot_cis_eqtl_cli <- function() .cis_main()

# ============================================================================
# ============================================================================
# Legacy name aliases
# ============================================================================

#' @rdname plot_manhattan_rasterized
#' @export
cis_plot_rasterized <- plot_manhattan_rasterized

# ============================================================================
# Short-name aliases
# ============================================================================

#' @rdname prepare_cis_eqtl_manhattan_data
#' @export
prep_cis <- prepare_cis_eqtl_manhattan_data

#' @rdname plot_manhattan_rasterized
#' @export
plot_cis <- plot_manhattan_rasterized

#' @rdname identify_cis_lead_snps
#' @export
lead_snps <- identify_cis_lead_snps
