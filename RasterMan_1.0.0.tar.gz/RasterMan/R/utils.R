# ============================================================================
# RasterMan - Shared Utilities
# ============================================================================

# Null-coalescing operator: use right-hand side when left is NULL
`%||%` <- function(a, b) if (!is.null(a)) a else b

#' Read GWAS/eQTL summary statistics with fast I/O
#'
#' Reads large GWAS result files efficiently using data.table, with optional
#' fst caching for repeat analyses.
#'
#' @param file Path to input file (supports gzip, bgzip).
#' @param chr_col Chromosome column name (default: "CHR").
#' @param bp_col Base-pair position column name (default: "BP").
#' @param p_col P-value column name (default: "P").
#' @param snp_col SNP ID column name (default: "SNP").
#' @param use_cache Use fst cache for repeat reads (requires fst package).
#' @param make_snp Create SNP column from CHR:BP if not present.
#' @param log10p_single Store -log10(P) as single-precision float (saves RAM).
#' @param nThread Number of threads for data.table (default: auto).
#' @param verbose Print progress messages.
#' @return A data.table with columns CHR, BP, P, LOG10P (and optionally SNP).
#' @export
read_gwas_data <- function(
    file,
    chr_col = "CHR",
    bp_col  = "BP",
    p_col   = "P",
    snp_col = "SNP",
    use_cache = FALSE,
    make_snp = FALSE,
    log10p_single = TRUE,
    nThread = NULL,
    verbose = TRUE
) {
  t_total_start <- Sys.time()

  if (is.null(nThread)) {
    nThread <- max(1L, parallel::detectCores() - 1L)
  }

  if (verbose) {
    cat("══════════════════════════════════════════\n")
    cat(sprintf("Reading: %s\n", basename(file)))
    cat("══════════════════════════════════════════\n")
  }

  if (!file.exists(file)) stop(sprintf("File not found: %s", file))

  file_size_mb <- file.info(file)$size / 1024^2
  if (verbose) cat(sprintf("Size: %.1f MB\n", file_size_mb))

  # ===== fst cache =====
  cache_tag <- paste(chr_col, bp_col, p_col, sep = "_")
  fst_file  <- paste0(tools::file_path_sans_ext(file), "_", cache_tag, "_cache.fst")

  if (use_cache && file.exists(fst_file) && requireNamespace("fst", quietly = TRUE)) {
    if (verbose) cat("Using cache...\n")
    gwas <- fst::read_fst(fst_file, as.data.table = TRUE)
    if (verbose) cat(sprintf("%s rows\n", format(nrow(gwas), big.mark = ",")))
    return(gwas)
  }

  # ===== header detection =====
  header <- tryCatch(
    names(data.table::fread(file, nrows = 0L)),
    error = function(e) stop(sprintf("Cannot read file: %s", e$message))
  )

  required_cols <- c(chr_col, bp_col, p_col)
  missing <- setdiff(required_cols, header)
  if (length(missing) > 0)
    stop(sprintf("Missing columns: %s", paste(missing, collapse = ", ")))

  cols_to_read <- c(chr_col, bp_col, p_col)
  has_snp <- snp_col %in% header
  if (has_snp && make_snp) cols_to_read <- c(cols_to_read, snp_col)

  # ===== read =====
  t_read <- Sys.time()
  gwas <- data.table::fread(
    file,
    select      = cols_to_read,
    nThread     = nThread,
    showProgress = verbose,
    data.table  = TRUE,
    integer64   = "integer64"
  )
  read_time <- as.numeric(difftime(Sys.time(), t_read, units = "secs"))

  if (verbose)
    cat(sprintf("%s rows  ⏱ %.2fs (%.0f MB/s)\n",
                format(nrow(gwas), big.mark = ","), read_time, file_size_mb / read_time))

  # ===== process =====
  original_rows <- nrow(gwas)

  old_names <- c(chr_col, bp_col, p_col)
  new_names <- c("CHR", "BP", "P")
  need_rename <- old_names != new_names
  if (any(need_rename))
    data.table::setnames(gwas, old_names[need_rename], new_names[need_rename])

  if (is.character(gwas$CHR)) {
    gwas[, CHR := {
      x <- CHR
      # Strip chr/Chr/CHR prefix
      if (any(grepl("^chr", x[1:min(100, .N)], ignore.case = TRUE)))
        x <- sub("^chr", "", x, ignore.case = TRUE)

      # Convert numeric chromosomes first to determine max autosome number
      int_x <- suppressWarnings(as.integer(x))
      max_auto <- max(int_x, na.rm = TRUE)
      if (!is.finite(max_auto)) max_auto <- 0L
      # Non-numeric names (X/Y/Z/W/MT etc.) assigned from max_auto+1
      # Fixed priority ensures cross-file consistency
      special_order <- c(
        "X",  "x",
        "Y",  "y",
        "Z",  "z",
        "W",  "w",
        "MT", "Mt", "mt", "M", "m"
      )
      # Collect non-numeric labels present in data, sorted by special_order priority
      na_mask    <- is.na(int_x)
      non_num    <- unique(x[na_mask])
      in_special <- non_num[non_num %in% special_order]
      not_special <- sort(non_num[!non_num %in% special_order])
      ordered_labels <- c(
        special_order[special_order %in% in_special],  # keep X<Y<Z<W<MT order
        not_special                                     # others alphabetically
      )
      # Deduplicate (X and x treated as identical)
      ordered_labels <- ordered_labels[!duplicated(toupper(ordered_labels))]

      if (length(ordered_labels) > 0) {
        offset <- max_auto + 1L
        for (i in seq_along(ordered_labels)) {
          lbl <- ordered_labels[i]
          # Case-insensitive match
          int_x[tolower(x) == tolower(lbl)] <- offset + i - 1L
        }
        cat(sprintf(
          "  Chromosome mapping (max autosome=%d): %s\n",
          max_auto,
          paste(sprintf("%s→%d", ordered_labels, offset + seq_along(ordered_labels) - 1L),
                collapse = ", ")
        ))
      }
      int_x
    }]
  }

  if (log10p_single) {
    gwas <- gwas[!is.na(P) & P > 0 & P <= 1 & !is.na(CHR) & !is.na(BP) & BP > 0L,
                 .(CHR, BP, P, LOG10P = as.single(-log10(P)))]
  } else {
    gwas <- gwas[!is.na(P) & P > 0 & P <= 1 & !is.na(CHR) & !is.na(BP) & BP > 0L,
                 .(CHR, BP, P, LOG10P = -log10(P))]
  }

  if (make_snp) {
    if (has_snp && snp_col %in% names(gwas)) {
      if (snp_col != "SNP") data.table::setnames(gwas, snp_col, "SNP")
    } else {
      gwas[, SNP := paste0(CHR, ":", BP)]
    }
  }

  if (nrow(gwas) == 0) stop("No valid data after filtering!")

  # ===== cache write =====
  if (use_cache && requireNamespace("fst", quietly = TRUE))
    fst::write_fst(gwas, fst_file, compress = 50)

  total_time <- as.numeric(difftime(Sys.time(), t_total_start, units = "secs"))
  if (verbose)
    cat(sprintf("Done %.2fs\n══════════════════════════════════════════\n", total_time))

  return(gwas)
}

#' Clear fst cache for a GWAS file
#' @param file Path to the original input file.
#' @param chr_col Chromosome column name used when creating the cache.
#' @param bp_col Base-pair position column name.
#' @param p_col P-value column name.
#' @export
clear_gwas_cache <- function(file, chr_col = "CHR", bp_col = "BP", p_col = "P") {
  cache_tag <- paste(chr_col, bp_col, p_col, sep = "_")
  fst_file  <- paste0(tools::file_path_sans_ext(file), "_", cache_tag, "_cache.fst")
  if (file.exists(fst_file)) {
    file.remove(fst_file)
    cat(sprintf("Deleted: %s\n", basename(fst_file)))
  } else {
    cat("No cache file found.\n")
  }
}

# ============================================================================
# Unified data reader
# ============================================================================

#' Unified data reader for GWAS, Cis-eQTL, and Trans-eQTL
#'
#' Rules:
#' \itemize{
#'   \item .gz file  → automatically builds an fst cache after first read;
#'         subsequent calls load from the cache (skips decompression).
#'   \item non-.gz   → plain fread, no cache.
#'   \item columns specified → selective read + column renaming.
#'   \item no columns specified → read all columns (e.g. trans-eQTL).
#'   \item p_col set, gene_col/gene_chr_col absent → GWAS mode:
#'         computes LOG10P and filters invalid rows.
#' }
#'
#' @param file Path to input file (.txt / .gz / etc.)
#' @param chr_col   Chromosome column name (optional)
#' @param bp_col    Position column name    (optional)
#' @param p_col     P-value column name     (optional)
#' @param snp_col   SNP-ID column name      (optional)
#' @param gene_col  Gene column name – activates cis-eQTL mode (optional)
#' @param gene_chr_col  Gene-chromosome column – activates trans-eQTL mode (optional)
#' @param gene_start_col Gene start column (optional)
#' @param gene_end_col   Gene end column   (optional)
#' @param nThread   Number of threads for fread (default: auto)
#' @param verbose   Print progress messages
#' @export
read_data <- function(
  file,
  chr_col        = NULL,
  bp_col         = NULL,
  p_col          = NULL,
  snp_col        = NULL,
  gene_col       = NULL,
  gene_chr_col   = NULL,
  gene_start_col = NULL,
  gene_end_col   = NULL,
  nThread        = NULL,
  verbose        = TRUE
) {
  if (!file.exists(file)) stop(sprintf("File not found: %s", file))
  if (is.null(nThread)) nThread <- max(1L, parallel::detectCores() - 1L)

  # ── Mode detection ─────────────────────────────────────────────────────────
  is_gwas  <- !is.null(p_col) && is.null(gene_col) && is.null(gene_chr_col)
  is_cis   <- !is.null(gene_col) && is.null(gene_chr_col)
  is_trans <- !is.null(gene_chr_col)
  mode_tag <- if (is_gwas) "gwas" else if (is_cis) "cis" else "trans"
  if (verbose) cat(sprintf("read_data [%s]: %s\n", mode_tag, basename(file)))

  # ── Columns to select ──────────────────────────────────────────────────────
  # Collect all user-specified column names (NULL means "not specified")
  user_cols <- list(
    chr = chr_col, bp = bp_col, p = p_col, snp = snp_col,
    gene = gene_col, gene_chr = gene_chr_col,
    gene_start = gene_start_col, gene_end = gene_end_col
  )
  has_col_spec <- any(!sapply(user_cols, is.null))

  # ── fst cache (gz files only) ──────────────────────────────────────────────
  use_cache <- grepl("\\.gz$", file, ignore.case = TRUE)
  if (use_cache) {
    # Cache key: file path + sorted column specs (so different selections don't collide)
    col_key  <- paste(sort(unlist(Filter(Negate(is.null), user_cols))), collapse = "_")
    fst_file <- paste0(file, if (nzchar(col_key)) paste0(".", col_key) else "", ".cache.fst")
    if (file.exists(fst_file) && requireNamespace("fst", quietly = TRUE)) {
      if (verbose) cat(sprintf("  fst cache hit: %s\n", basename(fst_file)))
      return(fst::read_fst(fst_file, as.data.table = TRUE))
    }
  }

  # ── Read ───────────────────────────────────────────────────────────────────
  if (!has_col_spec) {
    # No column spec → read everything (trans-eQTL raw read)
    if (verbose) cat("  Reading all columns\n")
    dt <- data.table::fread(file, nThread = nThread, showProgress = verbose,
                            data.table = TRUE)
  } else {
    # Selective read: resolve fuzzy column names against file header
    header <- names(data.table::fread(file, nrows = 0L, showProgress = FALSE))
    resolve <- function(col) {
      if (is.null(col)) return(NULL)
      tryCatch(.resolve_col(header, col),
               error = function(e) { warning(sprintf("Column '%s' not found, skipped", col)); NULL })
    }
    chr_real  <- resolve(chr_col)
    bp_real   <- resolve(bp_col)
    p_real    <- resolve(p_col)
    snp_real  <- resolve(snp_col)
    gene_real <- resolve(gene_col)
    gchr_real <- resolve(gene_chr_col)
    gst_real  <- resolve(gene_start_col)
    gen_real  <- resolve(gene_end_col)

    need <- unique(na.omit(c(chr_real, bp_real, p_real, snp_real,
                              gene_real, gchr_real, gst_real, gen_real)))
    if (verbose) cat(sprintf("  Reading columns: %s\n", paste(need, collapse = ", ")))

    # Column types
    cc <- character(0)
    if (!is.null(chr_real))  cc <- c(cc, setNames("character", chr_real))
    if (!is.null(bp_real))   cc <- c(cc, setNames("integer",   bp_real))
    if (!is.null(p_real))    cc <- c(cc, setNames("numeric",   p_real))
    if (!is.null(snp_real))  cc <- c(cc, setNames("character", snp_real))
    if (!is.null(gene_real)) cc <- c(cc, setNames("character", gene_real))
    if (!is.null(gchr_real)) cc <- c(cc, setNames("character", gchr_real))
    if (!is.null(gst_real))  cc <- c(cc, setNames("integer",   gst_real))
    if (!is.null(gen_real))  cc <- c(cc, setNames("integer",   gen_real))

    dt <- data.table::fread(file, select = need, colClasses = cc,
                            nThread = nThread, quote = "", fill = TRUE,
                            showProgress = verbose, data.table = TRUE)
    data.table::setDT(dt)

    # Rename to standard names
    rename <- function(from, to) {
      if (!is.null(from) && from %in% names(dt) && from != to)
        data.table::setnames(dt, from, to)
    }
    rename(chr_real,  "CHR")
    rename(bp_real,   "BP")
    rename(p_real,    "P")
    rename(snp_real,  "SNP")
    rename(gene_real, "Gene")
    rename(gchr_real, "GENE_CHR")
    rename(gst_real,  "GENE_START")
    rename(gen_real,  "GENE_END")
  }
  if (verbose) cat(sprintf("  %s rows x %d columns\n", format(nrow(dt), big.mark = ","), ncol(dt)))

  # ── Unified post-processing: CHR normalise + filter + LOG10P ──────────────
  # Runs whenever p_col is specified (gwas AND cis modes; skipped for trans raw reads)
  if (!is.null(p_col) && "P" %in% names(dt) && "CHR" %in% names(dt)) {

    # 1) CHR normalisation ---------------------------------------------------
    if (is.character(dt$CHR) || any(grepl("^[Cc][Hh][Rr]", dt$CHR))) {
      x     <- as.character(dt$CHR)
      x     <- sub("^[Cc][Hh][Rr]", "", x)
      int_x <- suppressWarnings(as.integer(x))
      if (any(is.na(int_x))) {
        max_auto <- max(int_x, na.rm = TRUE)
        if (!is.finite(max_auto)) max_auto <- 0L
        special_order <- c("X","x","Y","y","Z","z","W","w","MT","Mt","mt","M","m")
        non_num     <- unique(x[is.na(int_x)])
        in_special  <- non_num[non_num %in% special_order]
        not_special <- sort(non_num[!non_num %in% special_order])
        ordered_labels <- c(special_order[special_order %in% in_special], not_special)
        ordered_labels <- ordered_labels[!duplicated(toupper(ordered_labels))]
        if (length(ordered_labels) > 0) {
          offset <- max_auto + 1L
          for (i in seq_along(ordered_labels))
            int_x[tolower(x) == tolower(ordered_labels[i])] <- offset + i - 1L
          if (verbose)
            cat(sprintf("  Chromosome mapping (max_auto=%d): %s\n", max_auto,
              paste(sprintf("%s→%d", ordered_labels,
                            offset + seq_along(ordered_labels) - 1L),
                    collapse = ", ")))
        }
      }
      # Save original label for SNP ID generation before overwriting
      if (!"CHR_label" %in% names(dt))
        dt[, CHR_label := as.character(CHR)]
      dt[, CHR := int_x]
    } else {
      if (!"CHR_label" %in% names(dt))
        dt[, CHR_label := as.character(CHR)]
      dt[, CHR := as.integer(CHR)]
    }

    # 2) Filter invalid rows -------------------------------------------------
    n_before  <- nrow(dt)
    keep_expr <- quote(!is.na(P) & P > 0 & P <= 1 & !is.na(CHR) & !is.na(BP) & BP > 0L)
    if ("Gene" %in% names(dt))   # cis: also drop rows with missing gene
      keep_expr <- bquote(!is.na(P) & P > 0 & P <= 1 &
                          !is.na(CHR) & !is.na(BP) & BP > 0L &
                          !is.na(Gene) & Gene != "")
    dt <- dt[eval(keep_expr)]
    if (verbose && nrow(dt) < n_before)
      cat(sprintf("  Filtering invalid rows: %d rows (%.2f%%)\n",
                  n_before - nrow(dt), 100 * (n_before - nrow(dt)) / n_before))

    if (nrow(dt) == 0L) stop("No data remaining after filtering; check column names and data format.")

    # 3) LOG10P --------------------------------------------------------------
    dt[, LOG10P := as.single(-log10(P))]
    if (verbose) cat(sprintf("  LOG10P computed, valid rows: %s\n",
                             format(nrow(dt), big.mark = ",")))
  }

  # ── fst cache write ────────────────────────────────────────────────────────
  if (use_cache && requireNamespace("fst", quietly = TRUE)) {
    if (verbose) cat(sprintf("  Writing fst cache: %s\n", basename(fst_file)))
    fst::write_fst(dt, fst_file, compress = 50L)
  }

  dt
}


# ============================================================================
# Column name fuzzy matching (used by cis/trans eQTL)
# ============================================================================

.normalize_name <- function(x) {
  x <- trimws(x)
  x <- gsub("[`'\"]", "", x)
  x <- tolower(x)
  gsub("[^a-z0-9]+", "", x)
}

.resolve_col <- function(header, requested) {
  if (is.null(requested) || !nzchar(trimws(requested))) return(NULL)

  h0 <- header
  h1 <- .normalize_name(header)
  r1 <- .normalize_name(requested)

  idx <- which(h0 == requested)
  if (length(idx) == 1) return(h0[idx])

  idx <- which(h1 == r1)
  if (length(idx) == 1) return(h0[idx])

  idx <- which(grepl(r1, h1, fixed = TRUE) | grepl(h1, r1, fixed = TRUE))
  if (length(idx) == 1) return(h0[idx])

  if (length(idx) > 1) {
    cand <- h0[idx][order(nchar(h0[idx]))]
    warning(sprintf("Column '%s' matched multiple candidates: %s; using: %s",
                    requested, paste(cand, collapse = ", "), cand[1]))
    return(cand[1])
  }

  stop(sprintf(
    "Column '%s' not found (tried case/symbol normalisation).\nAvailable columns: %s",
    requested,
    paste(utils::head(header, 30), collapse = ", ")
  ))
}

# ============================================================================
# Chromosome normalization (used by trans eQTL)
# ============================================================================

.normalize_chromosome <- function(chr, max_auto = NULL) {
  chr       <- as.character(chr)
  chr_label <- chr
  chr       <- sub("^[Cc][Hh][Rr]", "", chr)

  int_x <- suppressWarnings(as.integer(chr))
  if (is.null(max_auto)) {
    max_auto <- max(int_x, na.rm = TRUE)
    if (!is.finite(max_auto)) max_auto <- 0L
  }

  special_order  <- c("X","x","Y","y","Z","z","W","w","MT","Mt","mt","M","m")
  non_num        <- unique(chr[is.na(int_x)])
  in_special     <- non_num[non_num %in% special_order]
  not_special    <- sort(non_num[!non_num %in% special_order])
  ordered_labels <- c(special_order[special_order %in% in_special], not_special)
  ordered_labels <- ordered_labels[!duplicated(toupper(ordered_labels))]

  if (length(ordered_labels) > 0) {
    offset <- max_auto + 1L
    for (i in seq_along(ordered_labels)) {
      int_x[tolower(chr) == tolower(ordered_labels[i])] <- offset + i - 1L
    }
    cat(sprintf(
      "  Chromosome mapping (max autosome=%d): %s\n",
      max_auto,
      paste(sprintf("%s→%d", ordered_labels, offset + seq_along(ordered_labels) - 1L),
            collapse = ", ")
    ))
  }

  list(chr_num = int_x, chr_label = chr_label)
}

# ============================================================================
# Color scheme system
# ============================================================================

#' Built-in color schemes for Manhattan plots
#'
#' A named list of alternating chromosome color pairs.
#' Each element has `even` (even chromosomes) and `odd` (odd chromosomes).
#'
#' Available schemes: classic, modern, colorblind, pastel, vibrant, gray
#'
#' @export
COLOR_SCHEMES <- list(
  classic    = list(even = "#4169E1", odd = "#FFA500"),
  modern     = list(even = "#2E86AB", odd = "#A23B72"),
  colorblind = list(even = "#0173B2", odd = "#DE8F05"),
  pastel     = list(even = "#AEC6CF", odd = "#FFB347"),
  vibrant    = list(even = "#FF6B6B", odd = "#4ECDC4"),
  gray       = list(even = "#808080", odd = "#D3D3D3")
)

#' Resolve color scheme to a named character vector
#'
#' Accepts a scheme name OR explicit hex colors. Custom colors override scheme.
#'
#' @param scheme  Character. One of the names in \code{COLOR_SCHEMES}, or \code{NULL}.
#' @param even    Character. Hex color for even chromosomes (overrides scheme).
#' @param odd     Character. Hex color for odd  chromosomes (overrides scheme).
#' @return Named character vector: \code{c(odd = "#...", even = "#...")}.
#' @export
resolve_color_scheme <- function(scheme = "modern", even = NULL, odd = NULL) {
  base <- if (!is.null(scheme) && scheme %in% names(COLOR_SCHEMES)) {
    COLOR_SCHEMES[[scheme]]
  } else {
    if (!is.null(scheme) && !is.null(scheme) && nchar(scheme) > 0)
      message(sprintf(
        "Warning: unknown color scheme '%s', valid values: %s; using modern",
        scheme, paste(names(COLOR_SCHEMES), collapse = ", ")
      ))
    COLOR_SCHEMES[["modern"]]
  }
  e <- if (!is.null(even)) even else base$even
  o <- if (!is.null(odd))  odd  else base$odd
  c(odd = o, even = e)
}

# ── Trans-eQTL gradient colour schemes ─────────────────────────────────────────────────────

#' Trans-eQTL built-in gradient colour schemes
#'
#' Each scheme has \code{low} (negative effect colour) and \code{high} (positive effect colour),
#' with white as the midpoint. Shares theme names with \code{COLOR_SCHEMES}.
#' @export
TRANS_COLOR_SCHEMES <- list(
  classic    = list(low = "#4169E1", high = "#FFA500"),
  modern     = list(low = "#2E86AB", high = "#A23B72"),
  colorblind = list(low = "#0173B2", high = "#DE8F05"),
  pastel     = list(low = "#AEC6CF", high = "#FFB347"),
  vibrant    = list(low = "#4ECDC4", high = "#FF6B6B"),
  gray       = list(low = "#808080", high = "#D3D3D3")
)

#' Resolve Trans-eQTL gradient colour scheme
#'
#' @param scheme  Scheme name, see \code{TRANS_COLOR_SCHEMES}. Default "modern".
#' @param low     Custom negative-effect colour (overrides scheme).
#' @param high    Custom positive-effect colour (overrides scheme).
#' @return List with \code{low} and \code{high}.
#' @export
resolve_trans_color_scheme <- function(scheme = "modern", low = NULL, high = NULL) {
  base <- if (!is.null(scheme) && scheme %in% names(TRANS_COLOR_SCHEMES)) {
    TRANS_COLOR_SCHEMES[[scheme]]
  } else {
    if (!is.null(scheme) && nchar(scheme) > 0)
      message(sprintf(
        "Warning: unknown gradient scheme '%s', valid values: %s; using modern",
        scheme, paste(names(TRANS_COLOR_SCHEMES), collapse = ", ")
      ))
    TRANS_COLOR_SCHEMES[["modern"]]
  }
  list(
    low  = if (!is.null(low))  low  else base$low,
    high = if (!is.null(high)) high else base$high
  )
}

# ============================================================================
# Short-name aliases  (read_gwas / read_cis / read_trans)
# ============================================================================

#' @describeIn read_data GWAS mode shortcut
#' @export
read_gwas <- function(file, chr_col = "CHR", bp_col = "BP", p_col = "P",
                      snp_col = NULL, ...) {
  read_data(file, chr_col = chr_col, bp_col = bp_col, p_col = p_col,
            snp_col = snp_col, ...)
}

#' @describeIn read_data Cis-eQTL mode shortcut
#' @export
read_cis <- function(file, chr_col = "CHR", bp_col = "BP", p_col = "P",
                     gene_col, snp_col = NULL, ...) {
  read_data(file, chr_col = chr_col, bp_col = bp_col, p_col = p_col,
            gene_col = gene_col, snp_col = snp_col, ...)
}

#' @describeIn read_data Trans-eQTL mode shortcut (all columns)
#' @export
read_trans <- function(file, ...) {
  read_data(file, ...)
}
