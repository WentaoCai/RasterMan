# ============================================================================
# RasterMan - GWAS Manhattan Plot Module
# ============================================================================

#' @importFrom ggplot2 ggplot aes geom_point geom_hline geom_abline annotate
#'   geom_text scale_x_continuous scale_color_manual theme_classic theme
#'   element_blank element_text labs ggsave guide_axis
#' @importFrom dplyr group_by summarise mutate left_join select filter arrange
#'   ungroup do head lag
#' @importFrom magrittr %>%
#' @importFrom data.table fread
#' @useDynLib RasterMan, .registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL

# ============================================================================
# QQ plot
# ============================================================================

#' Draw a QQ plot for GWAS P-values
#'
#' @param gwas Data frame with column \code{P} (p-values) and \code{LOG10P}.
#' @param params Named list of parameters (requires \code{sig_threshold}).
#' @return A ggplot2 object.
#' @export
plot_qqplot <- function(gwas, params) {

  cat("\n=== QQ plot ===\n")

  pvalues <- gwas$P
  pvalues <- pvalues[!is.na(pvalues) & pvalues >= 0 & pvalues <= 1]
  n_total <- length(pvalues)
  cat(sprintf("Valid P-values: %d\n", n_total))

  # Compute lambda (prefer C++, fallback to pure R median method)
  lambda <- tryCatch({
    fn <- tryCatch(get("calc_lambda_cpp", envir = globalenv()), error = function(e) NULL)
    if (is.null(fn))
      fn <- tryCatch(get("calc_lambda_cpp", envir = asNamespace("RasterMan")), error = function(e) NULL)
    if (!is.null(fn)) fn(pvalues)
    else stop("use_r")
  }, error = function(e) {
    # Pure R fallback: median method λ = median(χ²) / 0.4549
    chisq <- qchisq(pvalues, df = 1, lower.tail = FALSE)
    median(chisq, na.rm = TRUE) / qchisq(0.5, df = 1)
  })
  cat(sprintf("Genomic inflation factor (lambda): %.3f\n", lambda))

  pvalues_sorted <- sort(pvalues)
  observed <- -log10(pvalues_sorted)
  expected <- -log10(ppoints(n_total))
  qq_data  <- data.frame(expected = expected, observed = observed)

  if (n_total > 100000) {
    n_keep_low  <- 10000
    n_keep_high <- 10000
    n_sample_mid <- 80000
    low_indices  <- 1:n_keep_low
    high_indices <- (n_total - n_keep_high + 1):n_total
    mid_indices  <- round(seq(n_keep_low + 1, n_total - n_keep_high, length.out = n_sample_mid))
    keep_indices <- sort(c(low_indices, mid_indices, high_indices))
    qq_data_plot <- qq_data[keep_indices, ]
    cat(sprintf("Plotting with %d points\n", nrow(qq_data_plot)))
  } else {
    qq_data_plot <- qq_data
  }

  n_plot <- nrow(qq_data_plot)
  qq_data_plot$upper <- -log10(qbeta(0.975, 1:n_plot, n_plot:1))
  qq_data_plot$lower <- -log10(qbeta(0.025, 1:n_plot, n_plot:1))

  p <- ggplot2::ggplot(qq_data_plot, ggplot2::aes(x = expected, y = observed)) +
    ggplot2::geom_abline(intercept = 0, slope = 1, color = "red", linetype = "dashed", size = 0.8) +
    ggplot2::geom_point(size = 1, alpha = 0.6, color = "#2E86AB") +
    ggplot2::theme_classic() +
    ggplot2::theme(
      panel.grid.major = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      plot.title  = ggplot2::element_text(hjust = 0.5, size = 14, face = "bold"),
      axis.title  = ggplot2::element_text(size = 12),
      axis.text   = ggplot2::element_text(size = 10)
    ) +
    ggplot2::labs(
      x = expression(Expected ~ ~ -log[10](italic(P))),
      y = expression(Observed ~ ~ -log[10](italic(P))),
      title = "QQ Plot"
    )

  max_exp <- max(qq_data_plot$expected, na.rm = TRUE)
  max_obs <- max(qq_data_plot$observed, na.rm = TRUE)
  lambda_color <- if (lambda > 1.1 || lambda < 0.9) "red" else "black"

  p <- p + ggplot2::annotate(
    "text",
    x = max_exp * 0.05, y = max_obs * 0.95,
    label = sprintf("λ = %.3f", lambda),
    size = 5, hjust = 0, vjust = 1, color = lambda_color, fontface = "bold"
  )

  if (lambda > 1.1) {
    cat(sprintf("Warning: lambda > 1.1 (%.3f), possible population stratification\n", lambda))
  } else if (lambda < 0.9) {
    cat(sprintf("Warning: lambda < 0.9 (%.3f), possible over-correction\n", lambda))
  } else {
    cat("Lambda within normal range (0.9-1.1)\n")
  }

  return(p)
}

#' Combine a Manhattan plot and QQ plot side by side
#'
#' Requires the \pkg{patchwork} package.
#' @param p_manhattan A ggplot2 Manhattan plot.
#' @param p_qq A ggplot2 QQ plot.
#' @param width_ratio Relative widths, default \code{c(3, 1)}.
#' @return A patchwork object, or \code{NULL} if patchwork is unavailable.
#' @export
combine_manhattan_qq <- function(p_manhattan, p_qq, width_ratio = c(3, 1)) {
  if (!requireNamespace("patchwork", quietly = TRUE)) {
    message("Warning: patchwork not installed. Run: install.packages('patchwork')")
    return(NULL)
  }
  p_manhattan + p_qq + patchwork::plot_layout(ncol = 2, widths = width_ratio)
}

# ============================================================================
# Gene BED annotation
# ============================================================================

#' Read a BED file of gene coordinates for Lead SNP annotation
#'
#' @param bed_file Path to BED file (CHR, START, END, GENE_NAME, ...).
#' @return A data frame with columns CHR, START, END, GENE.
#' @export
read_gene_bed <- function(bed_file) {
  cat(sprintf("\nReading gene BED file: %s\n", bed_file))
  if (!file.exists(bed_file)) stop(sprintf("Error: gene BED file not found: %s", bed_file))

  genes <- tryCatch(
    data.table::fread(bed_file, data.table = FALSE, header = FALSE),
    error = function(e) stop(sprintf("Failed to read BED file: %s\nError: %s", bed_file, e$message))
  )

  if (ncol(genes) < 4)
    stop(sprintf("BED file format error: at least 4 columns required, found %d", ncol(genes)))

  colnames(genes)[1:4] <- c("CHR", "START", "END", "GENE")
  genes <- genes[!is.na(genes$CHR) & !is.na(genes$START) & !is.na(genes$END) & !is.na(genes$GENE), ]
  genes$CHR   <- gsub("^chr", "", genes$CHR, ignore.case = TRUE)
  genes$START <- as.numeric(genes$START)
  genes$END   <- as.numeric(genes$END)

  cat(sprintf("Read complete: %d genes\n", nrow(genes)))
  return(genes)
}

#' Annotate lead SNPs with nearest gene
#'
#' @param lead_snps Data frame of lead SNPs with CHR, BP, P columns.
#' @param genes Gene data frame from \code{\link{read_gene_bed}}.
#' @param max_distance Maximum distance (bp) to call a gene "nearby" (default 50 kb).
#' @return \code{lead_snps} with additional GENE, GENE_DIST, and label columns.
#' @export
annotate_nearest_gene <- function(lead_snps, genes, max_distance = 50000) {
  cat(sprintf("\n=== Annotate nearest genes ===\nMax distance threshold: %.1f kb\n", max_distance / 1000))

  if (nrow(lead_snps) == 0) { message("Warning: no lead SNPs to annotate"); return(lead_snps) }
  if (nrow(genes) == 0)     { message("Warning: gene list is empty");         return(lead_snps) }

  lead_snps$GENE      <- NA_character_
  lead_snps$GENE_DIST <- NA_real_

  for (i in seq_len(nrow(lead_snps))) {
    snp_chr  <- as.character(lead_snps$CHR[i])
    snp_pos  <- lead_snps$BP[i]
    chr_genes <- genes[genes$CHR == snp_chr, ]
    if (nrow(chr_genes) == 0) next

    chr_genes$DISTANCE <- sapply(seq_len(nrow(chr_genes)), function(j) {
      gs <- chr_genes$START[j]; ge <- chr_genes$END[j]
      if (snp_pos >= gs && snp_pos <= ge) 0L
      else if (snp_pos < gs) gs - snp_pos
      else snp_pos - ge
    })

    nearest_idx  <- which.min(chr_genes$DISTANCE)
    nearest_dist <- chr_genes$DISTANCE[nearest_idx]
    if (nearest_dist <= max_distance) {
      lead_snps$GENE[i]      <- chr_genes$GENE[nearest_idx]
      lead_snps$GENE_DIST[i] <- nearest_dist
    }
  }

  n_annotated <- sum(!is.na(lead_snps$GENE))
  cat(sprintf("Annotated: %d/%d lead SNPs\n", n_annotated, nrow(lead_snps)))

  lead_snps$label <- ifelse(
    !is.na(lead_snps$GENE),
    sprintf("%s (%s:%d)", lead_snps$GENE, lead_snps$CHR, lead_snps$BP),
    sprintf("%s:%d", lead_snps$CHR, lead_snps$BP)
  )
  return(lead_snps)
}

# ============================================================================
# Lead SNP identification
# ============================================================================

#' Identify lead SNPs by sliding window clumping
#'
#' @param gwas Data frame with CHR, BP, P, LOG10P, BP_cumulative columns.
#' @param window_size Clumping window size in bp (default 500 kb).
#' @param sig_threshold P-value threshold for significance (default 5e-8).
#' @param max_anno Maximum number of lead SNPs to annotate (default 50).
#' @return Data frame of lead SNPs.
#' @export
identify_lead_snps <- function(gwas, window_size = 500000,
                               sig_threshold = 5e-8, max_anno = 50) {
  cat(sprintf("\n=== Identify lead SNPs ===\nWindow: %.1f kb\nThreshold: %.2e\n",
              window_size / 1000, sig_threshold))

  sig_snps <- dplyr::filter(gwas, P < sig_threshold)
  sig_snps <- dplyr::arrange(sig_snps, CHR, BP)

  if (nrow(sig_snps) == 0) {
    message("Warning: no significant SNPs (P < threshold), skipping annotation")
    return(data.frame(CHR = integer(0), BP = numeric(0), P = numeric(0),
                      LOG10P = numeric(0), BP_cumulative = numeric(0),
                      label = character(0)))
  }

  lead_snps <- dplyr::do(
    dplyr::group_by(sig_snps, CHR),
    {
      chr_data <- dplyr::arrange(., P)
      used     <- rep(FALSE, nrow(chr_data))
      leads    <- list()
      for (i in seq_len(nrow(chr_data))) {
        if (used[i]) next
        lead_bp   <- chr_data$BP[i]
        in_window <- chr_data$BP >= (lead_bp - window_size / 2) &
                     chr_data$BP <= (lead_bp + window_size / 2)
        used[in_window] <- TRUE
        leads[[length(leads) + 1]] <- chr_data[i, ]
      }
      do.call(rbind, leads)
    }
  )
  lead_snps <- dplyr::ungroup(lead_snps)
  lead_snps <- dplyr::arrange(lead_snps, P)

  if (nrow(lead_snps) > max_anno) {
    cat(sprintf("Lead SNPs (%d) exceed max labels (%d), showing top %d\n",
                nrow(lead_snps), max_anno, max_anno))
    lead_snps <- utils::head(lead_snps, max_anno)
  }

  cat(sprintf("Final label count: %d\n", nrow(lead_snps)))
  return(lead_snps)
}

# ============================================================================
# Smart rasterization decision + execution
# ============================================================================

#' Decide whether and how to rasterize a plot
#'
#' @param gwas Data frame (used only for row count).
#' @param output_format One of "png", "tiff", "pdf".
#' @param mode One of "manhattan", "trans_eqtl", "cis_eqtl".
#' @param force_raster Force rasterization regardless of data size.
#' @param raster_method One of "auto", "smart", "multilevel", "adaptive", "basic", "off".
#' @return Named list with \code{use_raster}, \code{method}, \code{reason}.
#' @export
smart_rasterization_decision <- function(gwas, output_format, mode,
                                         force_raster, raster_method) {
  n_points <- nrow(gwas)

  if (output_format == "pdf")
    return(list(use_raster = FALSE, method = "standard", reason = "PDF format uses vector rendering"))

  if (raster_method != "auto") {
    if (raster_method == "off")
      return(list(use_raster = FALSE, method = "standard", reason = "rasterization disabled by user"))
    return(list(use_raster = TRUE, method = raster_method,
                reason = sprintf("user-specified method: %s", raster_method)))
  }

  if (force_raster || n_points > 1000000) {
    method <- if (n_points > 5000000) "multilevel"
               else if (n_points > 2000000) "adaptive"
               else "smart"
    return(list(use_raster = TRUE, method = method,
                reason = sprintf("%.1fM points -> %s", n_points / 1e6, method)))
  }

  if (mode %in% c("trans_eqtl", "cis_eqtl"))
    return(list(use_raster = TRUE, method = "smart",
                reason = sprintf("%s mode: forcing smart rasterization", mode)))

  list(use_raster = FALSE, method = "standard",
       reason = sprintf("small dataset (%d points), using standard plot", n_points))
}

#' Execute C++ smart rasterization
#'
#' @param gwas Data frame with plot coordinates.
#' @param method Rasterization method name.
#' @param mode Plot mode: "manhattan", "trans_eqtl", or "cis_eqtl".
#' @param sig_threshold Significance threshold on -log10(P) scale.
#' @param adaptive Use adaptive sampling (logical).
#' @param raster_width Grid width in pixels (NULL for auto).
#' @param raster_height Grid height in pixels (NULL for auto).
#' @return Data frame with columns x, y, color (integer color ID).
#' @export
execute_smart_rasterization <- function(gwas, method, mode, sig_threshold,
                                        adaptive, raster_width, raster_height) {
  if (mode == "manhattan") {
    x        <- gwas$BP_cumulative
    y        <- gwas$LOG10P
    # Encode odd/even from raw CHR: odd→1, even→2, ensures stable parity
    colors   <- ifelse(gwas$CHR %% 2 == 1, 1L, 2L)
    p_values <- gwas$P
  } else if (mode == "trans_eqtl") {
    x        <- gwas$Gene_pos
    y        <- gwas$SNP_pos
    colors   <- ifelse(gwas$LOG10P > sig_threshold, 2L, 1L)
    p_values <- gwas$P
  } else if (mode == "cis_eqtl") {
    x        <- gwas$Distance
    y        <- gwas$LOG10P
    colors   <- ifelse(gwas$LOG10P > sig_threshold, 2L, 1L)
    p_values <- gwas$P
  } else {
    stop("Unsupported mode: ", mode)
  }

  xmin     <- min(x, na.rm = TRUE); xmax <- max(x, na.rm = TRUE)
  ymin     <- min(y, na.rm = TRUE); ymax <- max(y, na.rm = TRUE)
  n_colors <- length(unique(colors))

  if (is.null(raster_width))  raster_width  <- 2000L
  if (is.null(raster_height)) raster_height <- 1000L

  # Resolve C++ functions from package namespace (.onLoad ensures they are present)
  .get_cpp_fn <- function(nm) {
    fn <- tryCatch(get(nm, envir = asNamespace("RasterMan"), inherits = FALSE),
                   error = function(e) NULL)
    if (!is.null(fn)) return(fn)
    stop(paste0(
      "C++ function '", nm, "' not available.\n",
      "Try reinstalling from source:\n",
      "  install.packages('RasterMan_1.0.0.tar.gz', repos=NULL, type='source')"
    ))
  }
  .rasterize_smart    <- .get_cpp_fn("rasterize_smart")
  .rasterize_multi    <- .get_cpp_fn("rasterize_multilevel")
  .rasterize_adaptive <- .get_cpp_fn("rasterize_adaptive_density")
  .rasterize_basic    <- .get_cpp_fn("rasterize_basic")

  result <- switch(method,
    smart = .rasterize_smart(x, y, colors, raster_width, raster_height,
                             xmin, xmax, ymin, ymax, n_colors, sig_threshold, adaptive),
    multilevel = {
      .rasterize_multi(x, y, colors, p_values,
                       xmin, xmax, ymin, ymax, n_colors,
                       as.integer(raster_width * 0.5), as.integer(raster_height * 0.5),
                       raster_width, raster_height, 10^(-sig_threshold))
    },
    adaptive = .rasterize_adaptive(x, y, colors, xmin, xmax, ymin, ymax, n_colors,
                                   raster_width, raster_height, 0.3),
    basic = .rasterize_basic(x, y, colors, raster_width, raster_height,
                             xmin, xmax, ymin, ymax, n_colors),
    stop("Unknown rasterization method: ", method)
  )

  # colors: 1 = odd chromosome, 2 = even chromosome
  # C++ result$color is 1-based index: 1=odd, 2=even
  raster_df <- data.frame(x = result$x, y = result$y, color = result$color)
  cat(sprintf("Rasterization complete: %d -> %d points (compression %.1f%%)\n",
              length(x), nrow(raster_df), 100 * (1 - nrow(raster_df) / length(x))))
  return(raster_df)
}

# ============================================================================
# Data preparation
# ============================================================================

#' Add cumulative BP positions for Manhattan plotting
#'
#' @param gwas Data frame with CHR and BP columns.
#' @return List with \code{gwas} (BP_cumulative added) and \code{chr_info}.
#' @export
prepare_manhattan_data <- function(gwas) {
  chr_lengths <- dplyr::summarise(
    dplyr::group_by(gwas, CHR),
    max_bp = max(BP)
  )
  chr_lengths <- dplyr::mutate(chr_lengths,
    bp_add    = dplyr::lag(cumsum(as.numeric(max_bp)), default = 0),
    bp_center = bp_add + max_bp / 2
  )
  gwas <- dplyr::left_join(gwas, dplyr::select(chr_lengths, CHR, bp_add), by = "CHR")
  gwas$BP_cumulative <- gwas$BP + gwas$bp_add
  list(gwas = gwas, chr_info = chr_lengths)
}

# ============================================================================
# Manhattan plot
# ============================================================================

#' Draw a GWAS Manhattan plot (with optional rasterization)
#'
#' @param gwas Data frame prepared by \code{\link{prepare_manhattan_data}}.
#' @param chr_info Chromosome info from \code{\link{prepare_manhattan_data}}.
#' @param params Named list of plotting parameters (see \code{\link{plot_gwas_cli}}).
#' @param genes Optional gene data frame from \code{\link{read_gene_bed}}.
#' @return A ggplot2 object.
#' @export
plot_manhattan <- function(gwas, chr_info, params, genes = NULL) {
  cat("\n=== Manhattan plot ===\n")

  # Lead SNP identification and annotation
  lead_snps <- NULL
  if (isTRUE(params$anno_snp)) {
    lead_snps <- identify_lead_snps(
      gwas,
      window_size   = params$window_size,
      sig_threshold = params$anno_threshold,
      max_anno      = params$max_anno
    )
    if (!is.null(genes) && nrow(lead_snps) > 0 && isTRUE(params$anno_gene)) {
      lead_snps <- annotate_nearest_gene(lead_snps, genes, max_distance = params$gene_distance)
    } else if (nrow(lead_snps) > 0) {
      lead_snps$label <- sprintf("%s:%d", lead_snps$CHR, lead_snps$BP)
    }
  }

  # Rasterization decision
  decision <- smart_rasterization_decision(
    gwas, params$output_format, params$mode, params$force_raster, params$raster_method
  )
  cat(sprintf("Rasterization: %s (method: %s)\n", decision$reason, decision$method))

  cpp_ok <- decision$use_raster &&
             !decision$method %in% c("standard", "off") &&
             existsMethod_safe("rasterize_smart")

  if (decision$use_raster && !decision$method %in% c("standard", "off") && !cpp_ok) {
    message("Warning: C++ rasterization not available, falling back to standard plot")
    decision$use_raster <- FALSE
    decision$method     <- "standard"
  }

  # Resolve color scheme
  chr_colors <- resolve_color_scheme(
    params$color_scheme,
    params$color_even,
    params$color_odd
  )

  # Base plot
  p <- ggplot2::ggplot() +
    ggplot2::theme_classic() +
    ggplot2::theme(
      legend.position       = "none",
      panel.grid.major.x    = ggplot2::element_blank(),
      panel.grid.minor.x    = ggplot2::element_blank(),
      axis.text.x           = ggplot2::element_text(angle = 0, hjust = 0.5)
    ) +
    ggplot2::labs(x = "Chromosome", y = expression(-log[10](P)),
                  title = params$title) +
    ggplot2::scale_x_continuous(
      breaks = chr_info$bp_center,
      labels = chr_info$CHR,
      guide  = ggplot2::guide_axis(check.overlap = TRUE)
    )

  # Add data layer
  if (cpp_ok) {
    cat("Using smart rasterization...\n")
    raster_df <- execute_smart_rasterization(
      gwas, decision$method, params$mode, -log10(params$sig_threshold),
      params$adaptive_sampling, params$raster_width, params$raster_height
    )
    # raster_df$color is chromosome integer index; assign color by parity
    # color==1 = odd chromosome, color==2 = even chromosome
    raster_df$chr_parity <- ifelse(raster_df$color == 1L, "odd", "even")
    p <- p +
      ggplot2::geom_point(
        data = raster_df,
        ggplot2::aes(x = x, y = y, color = chr_parity),
        size = params$point_size %||% 0.8, alpha = params$point_alpha %||% 0.7
      ) +
      ggplot2::scale_color_manual(
        values = c(odd = chr_colors[["odd"]], even = chr_colors[["even"]])
      )
  } else {
    cat("Using standard plot...\n")
    # Assign color by chromosome parity, consistent with color_scheme
    gwas$chr_parity <- ifelse(gwas$CHR %% 2 == 1, "odd", "even")
    p <- p +
      ggplot2::geom_point(
        data = gwas,
        ggplot2::aes(x = BP_cumulative, y = LOG10P, color = chr_parity),
        size = params$point_size %||% 0.8, alpha = params$point_alpha %||% 0.7
      ) +
      ggplot2::scale_color_manual(
        values = c(odd = chr_colors[["odd"]], even = chr_colors[["even"]])
      )
  }

  # Significance line
  p <- p + ggplot2::geom_hline(
    yintercept = -log10(params$sig_threshold),
    linetype = "dashed", color = params$sig_color %||% "red"
  )

  # Lead SNP labels
  if (!is.null(lead_snps) && nrow(lead_snps) > 0) {
    cat(sprintf("\nAdding %d lead SNP labels...\n", nrow(lead_snps)))
    if (requireNamespace("ggrepel", quietly = TRUE)) {
      p <- p + ggrepel::geom_text_repel(
        data          = lead_snps,
        ggplot2::aes(x = BP_cumulative, y = LOG10P, label = label),
        size          = params$label_size %||% 2.5, box.padding = 0.5, point.padding = 0.3,
        segment.color = "grey50", segment.size = 0.3,
        max.overlaps  = 20, force = 2, color = "black"
      )
    } else {
      p <- p + ggplot2::geom_text(
        data        = lead_snps,
        ggplot2::aes(x = BP_cumulative, y = LOG10P, label = label),
        size        = params$label_size %||% 2.5, vjust = -0.5, color = "black"
      )
    }
  }

  return(p)
}

# Helper: safe check for existence of compiled C++ function
existsMethod_safe <- function(fname) tryCatch(exists(fname, mode = "function"), error = function(e) FALSE)

# ============================================================================
# Argument parsing (internal)
# ============================================================================

.gwas_parse_arguments <- function() {
  args <- commandArgs(trailingOnly = TRUE)

  params <- list(
    input_file        = NULL,
    output_prefix     = "gwas_plot",
    output_format     = "png",
    dpi               = 300L,
    width             = 12,
    height            = 6,
    sig_threshold     = 5e-8,
    threads           = 4L,
    chr_col           = "CHR",
    bp_col            = "BP",
    p_col             = "P",
    snp_col           = "SNP",
    anno_snp          = FALSE,
    window_size       = 500000,
    anno_threshold    = 5e-8,
    max_anno          = 50L,
    anno_gene         = FALSE,
    gene_bed          = NULL,
    gene_distance     = 50000,
    qq_plot           = FALSE,
    qq_only           = FALSE,
    qq_combine        = FALSE,
    raster_method     = "auto",
    raster_width      = 2000L,
    raster_height     = 1000L,
    force_raster      = FALSE,
    no_raster         = FALSE,
    adaptive_sampling = TRUE,
    mode              = "manhattan",
    # Color scheme parameters
    color_scheme      = "modern",
    color_even        = NULL,
    color_odd         = NULL,
    # Style parameters
    point_size        = 0.8,
    point_alpha       = 0.7,
    label_size        = 2.5,
    sig_color         = "red",
    title             = NULL,
    chr_background    = TRUE
  )

  i <- 1L
  while (i <= length(args)) {
    a <- args[i]
    nxt <- function() { i <<- i + 1L; args[i] }

    if      (a == "--help" || a == "-h")  { .gwas_print_help(); quit(save = "no", status = 0) }
    else if (a == "--format")             params$output_format     <- nxt()
    else if (a == "--dpi")                params$dpi               <- as.integer(nxt())
    else if (a == "--width")              params$width             <- as.numeric(nxt())
    else if (a == "--height")             params$height            <- as.numeric(nxt())
    else if (a == "--threads")            params$threads           <- as.integer(nxt())
    else if (a == "--mode")               params$mode              <- nxt()
    else if (a == "--sig-threshold")      params$sig_threshold     <- as.numeric(nxt())
    else if (a == "--chr-col")            params$chr_col           <- nxt()
    else if (a == "--bp-col")             params$bp_col            <- nxt()
    else if (a == "--p-col")              params$p_col             <- nxt()
    else if (a == "--snp-col")            params$snp_col           <- nxt()
    else if (a == "--anno-snp")           params$anno_snp          <- TRUE
    else if (a == "--window-size")        params$window_size       <- as.numeric(nxt())
    else if (a == "--anno-threshold")     params$anno_threshold    <- as.numeric(nxt())
    else if (a == "--max-anno")           params$max_anno          <- as.integer(nxt())
    else if (a == "--anno-gene")          params$anno_gene         <- TRUE
    else if (a == "--gene-bed")           params$gene_bed          <- nxt()
    else if (a == "--gene-distance")      params$gene_distance     <- as.numeric(nxt())
    else if (a == "--qq-plot")            params$qq_plot           <- TRUE
    else if (a == "--qq-only")            { params$qq_only <- TRUE;  params$qq_plot <- TRUE }
    else if (a == "--qq-combine")         { params$qq_combine <- TRUE; params$qq_plot <- TRUE }
    else if (a == "--raster-method")      params$raster_method     <- nxt()
    else if (a == "--raster-width")       params$raster_width      <- as.integer(nxt())
    else if (a == "--raster-height")      params$raster_height     <- as.integer(nxt())
    else if (a == "--force-raster")       params$force_raster      <- TRUE
    else if (a == "--no-raster")          { params$no_raster <- TRUE; params$raster_method <- "off" }
    else if (a == "--no-adaptive")        params$adaptive_sampling <- FALSE
    else if (a == "--color-scheme")       params$color_scheme      <- nxt()
    else if (a == "--color-even")         params$color_even        <- nxt()
    else if (a == "--color-odd")          params$color_odd         <- nxt()
    else if (a == "--point-size")         params$point_size        <- as.numeric(nxt())
    else if (a == "--point-alpha")        params$point_alpha       <- as.numeric(nxt())
    else if (a == "--label-size")         params$label_size        <- as.numeric(nxt())
    else if (a == "--sig-color")          params$sig_color         <- nxt()
    else if (a == "--title")              params$title             <- nxt()
    else if (a == "--no-background")      params$chr_background    <- FALSE
    else if (!startsWith(a, "--") && is.null(params$input_file)) params$input_file <- a

    i <- i + 1L
  }

  # Use anno_threshold = sig_threshold if not explicitly set
  if (params$anno_threshold == 5e-8 && params$sig_threshold != 5e-8)
    params$anno_threshold <- params$sig_threshold

  if (is.null(params$input_file))
    stop("Error: input file required\nUse --help to see usage")

  params
}

.gwas_print_help <- function() {
  cat("
RasterMan - GWAS visualization tool

Usage:
  Rscript -e \"RasterMan::plot_gwas_cli()\" <input_file> [options]

  Or using the installed CLI script:
  plot_gwas.R <input_file> [options]

Basic options:
  --format FORMAT         Output format (png|tiff|pdf, default: png)
  --dpi DPI               Resolution (default: 300)
  --width INCHES          Plot width in inches (default: 12)
  --height INCHES         Plot height in inches (default: 6)
  --sig-threshold VALUE   Significance threshold (default: 5e-8)

Column name options:
  --chr-col NAME          Chromosome column (default: CHR)
  --bp-col NAME           Position column (default: BP)
  --p-col NAME            P-value column (default: P)
  --snp-col NAME          SNP ID column (default: SNP)

SNP annotation options:
  --anno-snp              Enable lead SNP annotation
  --window-size SIZE      Window size in bp (default: 500000)
  --anno-threshold VALUE  Annotation threshold
  --max-anno N            Max annotations (default: 50)
  --anno-gene             Enable gene annotation
  --gene-bed FILE         Gene BED file
  --gene-distance SIZE    Gene distance threshold in bp (default: 50000)

QQ plot options:
  --qq-plot               Also produce a QQ plot
  --qq-only               QQ plot only
  --qq-combine            Combine Manhattan + QQ into one figure

Rasterization options:
  --raster-method METHOD  auto|smart|multilevel|adaptive|basic|off (default: auto)
  --raster-width N        Grid width
  --raster-height N       Grid height
  --force-raster          Force rasterization
  --no-raster             Disable rasterization
  --no-adaptive           Disable adaptive sampling

Common GWAS software column names:
  PLINK:    --chr-col CHR --bp-col BP --p-col P
  GCTA:     --chr-col Chr --bp-col bp --p-col p
  BOLT-LMM: --chr-col SNP_CHR --bp-col SNP_BP --p-col P_BOLT_LMM
  GEMMA:    --chr-col chr --bp-col ps --p-col p_wald
  SAIGE:    --chr-col CHR --bp-col POS --p-col p.value
")
}

# ============================================================================
# Exported CLI entry point
# ============================================================================

#' GWAS Manhattan plot command-line interface
#'
#' Run as: \code{Rscript -e "RasterMan::plot_gwas_cli()" mydata.mlma}
#'
#' Or via the installed script \code{plot_gwas.R} in
#' \code{system.file("scripts", package = "RasterMan")}.
#'
#' @export
plot_gwas_cli <- function() {
  cat("=== RasterMan - GWAS visualization tool ===\n\n")

  params <- tryCatch(.gwas_parse_arguments(), error = function(e) {
    message("  Argument parse error: ", e$message)
    quit(save = "no", status = 1)
  })

  t0    <- Sys.time()
  gwas  <- tryCatch(
    read_gwas_data(params$input_file, params$chr_col, params$bp_col, params$p_col, params$snp_col),
    error = function(e) { message("\nData read failed: ", e$message); quit(save = "no", status = 1) }
  )

  genes <- NULL
  if (isTRUE(params$anno_gene)) {
    if (is.null(params$gene_bed)) {
      message("Warning: --anno-gene enabled but --gene-bed not provided")
    } else {
      genes <- tryCatch(read_gene_bed(params$gene_bed),
                        error = function(e) { message("Gene BED file read failed: ", e$message); NULL })
    }
  }

  result    <- prepare_manhattan_data(gwas)
  gwas      <- result$gwas
  chr_info  <- result$chr_info

  save_plot <- function(p, suffix, w, h) {
    outf <- if (nchar(suffix) > 0)
      sprintf("%s_%s.%s", params$output_prefix, suffix, params$output_format)
    else
      sprintf("%s.%s", params$output_prefix, params$output_format)
    cat(sprintf("Saving: %s\n", outf))
    ggplot2::ggsave(outf, plot = p, width = w, height = h, dpi = params$dpi, units = "in")
  }

  if (params$qq_only) {
    save_plot(plot_qqplot(gwas, params), "qq", 6, 6)

  } else if (params$qq_combine) {
    pm <- plot_manhattan(gwas, chr_info, params, genes)
    pq <- plot_qqplot(gwas, params)
    pc <- combine_manhattan_qq(pm, pq)
    if (!is.null(pc)) save_plot(pc, "combined", params$width + 4, params$height)
    else {
      save_plot(pm, "manhattan", params$width, params$height)
      save_plot(pq, "qq",       6, 6)
    }

  } else {
    pm <- plot_manhattan(gwas, chr_info, params, genes)
    save_plot(pm, "", params$width, params$height)
    if (params$qq_plot) save_plot(plot_qqplot(gwas, params), "qq", 6, 6)
  }

  cat(sprintf("\nDone! Elapsed: %.2fs\n",
              as.numeric(difftime(Sys.time(), t0, units = "secs"))))
}

# ============================================================================
# Short-name aliases
# ============================================================================

#' @rdname prepare_manhattan_data
#' @export
prep_gwas <- prepare_manhattan_data

#' @rdname plot_manhattan
#' @export
plot_gwas <- plot_manhattan

#' @rdname plot_qqplot
#' @export
plot_qq <- plot_qqplot
