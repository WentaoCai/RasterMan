# ── Auto-load C++ rasterization engine on package attach ─────────────────────
# RcppExports.R defines R wrappers, but they only work when the compiled .so
# is properly loaded.  If the .so symbols are missing (wrong arch, binary
# install on a different platform, etc.), we fall back to sourceCpp() on the
# bundled copy in inst/src/ so the functions land in the package environment.
# ─────────────────────────────────────────────────────────────────────────────

.onLoad <- function(libname, pkgname) {
  # Actually try to *call* the function — just having the R wrapper in the
  # namespace is not enough; we need the underlying .so symbol to be present.
  sym_ok <- tryCatch({
    fn <- get("rasterize_basic", envir = asNamespace(pkgname), inherits = FALSE)
    fn(numeric(0), numeric(0), integer(0), 2L, 2L, 0, 1, 0, 1, 1L)
    TRUE
  }, error = function(e) FALSE)

  if (sym_ok) return(invisible(NULL))

  # .so symbols missing — compile from the bundled source file
  cpp_file <- system.file("src", "gwas_smart_rasterization.cpp",
                          package = pkgname)
  if (!nzchar(cpp_file) || !file.exists(cpp_file)) return(invisible(NULL))
  if (!requireNamespace("Rcpp", quietly = TRUE))   return(invisible(NULL))

  tryCatch({
    # env = parent.env(asNamespace(pkgname)) loads into the package namespace
    # but that is locked; use the namespace environment directly via a small
    # trick: compile to a temp env then copy the bindings.
    tmp_env <- new.env(parent = baseenv())
    Rcpp::sourceCpp(cpp_file, env = tmp_env, rebuild = FALSE, verbose = FALSE)

    # Unlock namespace and inject
    ns <- asNamespace(pkgname)
    fns <- c("rasterize_basic", "rasterize_smart",
             "rasterize_multilevel", "rasterize_adaptive_density",
             "analyze_data_distribution", "calc_lambda_cpp")
    for (nm in fns) {
      if (exists(nm, envir = tmp_env, inherits = FALSE)) {
        unlockBinding(as.name(nm), ns)
        assign(nm, get(nm, envir = tmp_env), envir = ns)
        lockBinding(as.name(nm), ns)
      }
    }

    packageStartupMessage(
      "[RasterMan] C++ rasterization engine loaded via sourceCpp (JIT fallback).\n",
      "            For best performance reinstall from source:\n",
      "            install.packages('RasterMan_1.0.0.tar.gz', repos=NULL, type='source')"
    )
  }, error = function(e) {
    packageStartupMessage(
      "[RasterMan] Warning: C++ engine could not be loaded; plots will use standard mode.\n",
      "            Details: ", conditionMessage(e)
    )
  })

  invisible(NULL)
}
