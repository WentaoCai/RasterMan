#' RasterMan: Smart Rasterization for Genomic Association Manhattan Plots
#'
#' High-performance Manhattan plot visualization for large-scale genomic
#' association studies. Uses adaptive C++ rasterization to handle million-scale
#' SNP datasets efficiently, achieving ~20x speedup and ~87% memory reduction
#' compared to standard ggplot2 geom_point.
#'
#' @section Key functions:
#' \describe{
#'   \item{\code{\link{plot_gwas_cli}}}{GWAS Manhattan + QQ plot (command-line)}
#'   \item{\code{\link{plot_cis_eqtl_cli}}}{Cis-eQTL Manhattan plot (command-line)}
#'   \item{\code{\link{plot_trans_eqtl_cli}}}{Trans-eQTL 2D Manhattan plot (command-line)}
#'   \item{\code{\link{plot_manhattan}}}{GWAS Manhattan plot (R API)}
#'   \item{\code{\link{plot_qqplot}}}{QQ plot with lambda inflation factor (R API)}
#'   \item{\code{\link{read_gwas_data}}}{Fast GWAS data reader (R API)}
#'   \item{\code{\link{read_gene_bed}}}{Read BED file for gene annotation (R API)}
#'   \item{\code{\link{identify_lead_snps}}}{Sliding-window lead SNP clumping (R API)}
#'   \item{\code{\link{annotate_nearest_gene}}}{Annotate lead SNPs with nearest gene (R API)}
#'   \item{\code{\link{prepare_manhattan_data}}}{Compute cumulative BP positions (R API)}
#'   \item{\code{\link{smart_rasterization_decision}}}{Auto rasterization strategy (R API)}
#'   \item{\code{\link{execute_smart_rasterization}}}{Execute C++ rasterization (R API)}
#' }
#'
#' @section Rasterization methods:
#' \describe{
#'   \item{smart}{Stratified smart rasterization (100k-2M points)}
#'   \item{adaptive}{Adaptive density rasterization (2M-5M points)}
#'   \item{multilevel}{Multi-level rasterization (5M+ points)}
#'   \item{basic}{Basic grid rasterization (fastest)}
#' }
#'
#' @section CLI Usage:
#' After installation, use the scripts in \code{system.file("scripts", package = "RasterMan")}:
#'
#' \preformatted{
#' # GWAS
#' Rscript plot_gwas.R gwas.mlma --chr-col Chr --bp-col bp --p-col p
#'
#' # Cis-eQTL
#' Rscript plot_cis_eqtl.R cis.txt --gene-col Gene --chr-col Chr
#'
#' # Trans-eQTL
#' Rscript plot_trans_eqtl.R trans.txt --slope-col beta
#' }
#'
#' @docType package
#' @name RasterMan-package
#' @aliases RasterMan
"_PACKAGE"
