test_that("prepare_manhattan_data works", {
  gwas <- data.table::data.table(
    CHR = c(1L, 1L, 2L, 2L),
    BP  = c(100L, 200L, 150L, 250L),
    P   = c(0.01, 0.001, 0.05, 0.1),
    LOG10P = c(2, 3, 1.3, 1)
  )
  result <- prepare_manhattan_data(gwas)
  expect_true("BP_cumulative" %in% names(result$gwas))
  expect_true("bp_center" %in% names(result$chr_info))
  expect_equal(nrow(result$gwas), 4)
})

test_that("smart_rasterization_decision returns correct structure", {
  gwas <- data.frame(matrix(nrow = 500, ncol = 1))
  res  <- smart_rasterization_decision(gwas, "pdf", "manhattan", FALSE, "auto")
  expect_false(res$use_raster)  # PDF always stays vector

  gwas2 <- data.frame(matrix(nrow = 2000000, ncol = 1))
  res2  <- smart_rasterization_decision(gwas2, "png", "manhattan", FALSE, "auto")
  expect_true(res2$use_raster)
  expect_equal(res2$method, "adaptive")
})

test_that("identify_lead_snps returns data frame", {
  set.seed(42)
  gwas <- data.table::data.table(
    CHR = rep(1L, 100),
    BP  = seq(1e6, 1e8, length.out = 100L),
    P   = c(1e-9, runif(99, 0.01, 1)),
    LOG10P = NA_real_,
    BP_cumulative = seq(1e6, 1e8, length.out = 100L)
  )
  gwas$LOG10P <- -log10(gwas$P)
  leads <- identify_lead_snps(gwas, sig_threshold = 5e-8)
  expect_s3_class(leads, "data.frame")
  expect_equal(nrow(leads), 1)
})
