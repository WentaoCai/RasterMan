#!/usr/bin/env Rscript
# =============================================================================
# RasterMan - Cis-eQTL Manhattan plot
# =============================================================================
# Usage:
#   Rscript plot_cis_eqtl.R <input_file> [options]
#   Rscript plot_cis_eqtl.R --help
#
# Basic options:
#   -o, --output FILE       Output filename      (default: cis_eqtl_manhattan.png)
#   --width INCHES          Plot width           (default: 14)
#   --height INCHES         Plot height          (default: 7)
#   --dpi DPI               Resolution           (default: 300)
#   --title TEXT            Plot title
#   --color-scheme NAME     modern | classic | colorblind | pastel | vibrant | gray
#
# Column names:
#   --chr-col  NAME         Chromosome column    (default: Chr)
#   --bp-col   NAME         Position column      (default: Position)
#   --gene-col NAME         Gene column          (default: Gene)
#   --p-col    NAME         P-value column       (default: Pvalue)
#   --snp-col  NAME         SNP ID column        (optional, auto chr:pos if absent)
#
# Lead SNP annotation:
#   --min-gene-logp VALUE   Min -log10(P) for labelling  (default: 5)
#   --max-labels N          Max gene labels              (default: NULL = all)
#   --sig-threshold VALUE   Significance threshold       (default: 1e-5)
#
# Highlight cis-eGenes:
#   --anno-gene FILE        File with one gene name per line (or table with gene column)
#                           Highlighted in red and labelled preferentially
#   --highlight-color COLOR Highlight colour             (default: red)
#   --highlight-size  SIZE  Highlight point size         (default: 1.5)
#
# Rasterization (C++ accelerated, recommended for >100k points):
#   --raster-method METHOD  auto | smart | multilevel | adaptive | basic | off
#                           auto      : auto-select (recommended)
#                           smart     : density-aware, preserves signals   100k-1M pts
#                           multilevel: fine grid for signals + coarse bg  1M+ pts ★
#                           adaptive  : density-subdivided grid            high memory
#                           basic     : fastest, may obscure weak signals
#                           off       : standard ggplot (no rasterization)
#   --raster-width  N       Grid width  (default: auto)
#   --raster-height N       Grid height (default: auto)
#   --force-raster          Force rasterization regardless of data size
#   --no-raster             Disable rasterization
#
# Style:
#   --no-background         No chromosome background bands
#
# Performance reference (31M data points):
#   no raster : ~30 min  | quality 100% | memory: overflow
#   basic     : ~2 min   | quality  85% | memory: low
#   smart     : ~1.5 min | quality  92% | memory: medium
#   multilevel: ~1 min   | quality  95% | memory: medium  ★ recommended
#   adaptive  : ~2.5 min | quality  93% | memory: high
#
# Examples:
#   Rscript plot_cis_eqtl.R cis.txt.gz
#   Rscript plot_cis_eqtl.R cis.txt.gz --raster-method multilevel --dpi 300
#   Rscript plot_cis_eqtl.R cis.txt.gz --anno-gene egenes.txt --color-scheme colorblind
#   Rscript plot_cis_eqtl.R cis.txt.gz --chr-col chromosome --bp-col pos --p-col pvalue
# =============================================================================

if (!requireNamespace("RasterMan", quietly = TRUE)) {
  stop("RasterMan is not installed.\n",
       "Install from source: install.packages('RasterMan_1.0.0.tar.gz', repos=NULL, type='source')")
}

RasterMan::plot_cis_eqtl_cli()
