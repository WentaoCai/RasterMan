#!/usr/bin/env Rscript
# =============================================================================
# RasterMan - GWAS Manhattan plot
# =============================================================================
# Usage:
#   Rscript plot_gwas.R <input_file> [options]
#   Rscript plot_gwas.R --help
#
# Basic options:
#   --output PREFIX         Output file prefix (default: manhattan)
#   --format FORMAT         png | tiff | pdf  (default: png)
#   --width INCHES          Plot width  (default: 12)
#   --height INCHES         Plot height (default: 6)
#   --dpi DPI               Resolution  (default: 300)
#   --sig-threshold VALUE   Significance threshold (default: 5e-8)
#   --color-scheme NAME     modern | classic | colorblind | pastel | vibrant | gray
#
# Column names:
#   --chr-col NAME          Chromosome column  (default: CHR)
#   --bp-col  NAME          Position column    (default: BP)
#   --p-col   NAME          P-value column     (default: P)
#   --snp-col NAME          SNP ID column      (default: SNP)
#
# SNP annotation:
#   --anno-snp              Annotate lead SNPs
#   --window-size BP        LD window in bp    (default: 500000)
#   --anno-threshold VALUE  Annotation p-value threshold
#   --max-anno N            Max annotations    (default: 50)
#   --anno-gene             Annotate nearest gene
#   --gene-bed FILE         Gene BED file (required with --anno-gene)
#   --gene-distance BP      Max gene distance  (default: 50000)
#
# QQ plot:
#   --qq-plot               Also save a QQ plot
#   --qq-only               QQ plot only
#   --qq-combine            Combine Manhattan + QQ into one figure
#
# Rasterization:
#   --raster-method METHOD  auto | smart | multilevel | adaptive | basic | off
#   --raster-width  N       Grid width
#   --raster-height N       Grid height
#   --force-raster          Force rasterization
#   --no-raster             Disable rasterization
#
# Common column-name presets (GCTA/PLINK/BOLT-LMM auto-detected):
#   GCTA .mlma  : --chr-col Chr  --bp-col bp  --p-col p
#   PLINK .assoc: --chr-col CHR  --bp-col BP  --p-col P  --snp-col SNP
#   BOLT-LMM    : --chr-col CHR  --bp-col BP  --p-col P_BOLT_LMM
#
# Examples:
#   Rscript plot_gwas.R data.mlma --chr-col Chr --bp-col bp --p-col p
#   Rscript plot_gwas.R data.mlma --anno-snp --qq-combine --color-scheme colorblind
#   Rscript plot_gwas.R data.assoc.gz --raster-method smart --format tiff --dpi 600
# =============================================================================

if (!requireNamespace("RasterMan", quietly = TRUE)) {
  stop("RasterMan is not installed.\n",
       "Install from source: install.packages('RasterMan_1.0.0.tar.gz', repos=NULL, type='source')")
}

RasterMan::plot_gwas_cli()
