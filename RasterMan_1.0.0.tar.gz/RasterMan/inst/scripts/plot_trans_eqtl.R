#!/usr/bin/env Rscript
# =============================================================================
# RasterMan - Trans-eQTL 2D Manhattan plot
# =============================================================================
# Usage:
#   Rscript plot_trans_eqtl.R <input_file> [options]
#   Rscript plot_trans_eqtl.R --help
#
# Basic options:
#   -o, --output FILE       Output filename      (default: trans_eqtl_manhattan.png)
#   --width INCHES          Plot width           (default: 10)
#   --height INCHES         Plot height          (default: 10)
#   --dpi DPI               Resolution           (default: 300)
#   --title TEXT            Plot title
#   --color-scheme NAME     modern | classic | colorblind | pastel | vibrant | gray
#
# Required column names:
#   --chr-col        NAME   SNP chromosome column      (default: Chr)
#   --pos-col        NAME   SNP position column        (default: Pos)
#   --p-col          NAME   P-value column             (default: Pvalue)
#   --gene-chr-col   NAME   Gene chromosome column     (default: Gene_chr)
#   --gene-start-col NAME   Gene start position column (default: Start)
#   --gene-end-col   NAME   Gene end position column   (default: End)
#
# Optional column names:
#   --snp-col   NAME        SNP ID column  (optional, auto chr:pos if absent)
#   --gene-col  NAME        Gene name column (optional)
#   --slope-col NAME        Effect/Beta column for colour encoding (optional)
#   --effect-col NAME       Same as --slope-col
#
# Rasterization:
#   --raster-method METHOD  basic | off  (default: auto, basic when >100k points)
#   --raster-width N        Grid size    (default: 2000)
#   --force-raster          Force rasterization
#   --no-raster             Disable rasterization
#
# Style:
#   --no-background         No chromosome background bands
#
# Features:
#   - X-axis: SNP genomic position
#   - Y-axis: gene genomic position
#   - Colour: effect direction (blue=negative, red=positive) if --slope-col given
#             otherwise -log10(P) viridis scale
#   - Supports chr prefix (chr1, chr2, chrX) and sex chromosomes (X, Y, MT)
#
# Examples:
#   Rscript plot_trans_eqtl.R trans.txt.gz
#   Rscript plot_trans_eqtl.R trans.txt.gz --slope-col beta --color-scheme modern
#   Rscript plot_trans_eqtl.R trans.txt.gz --chr-col CHR --pos-col POS --p-col P \
#       --gene-chr-col gene_chr --gene-start-col gene_start --gene-end-col gene_end
# =============================================================================

if (!requireNamespace("RasterMan", quietly = TRUE)) {
  stop("RasterMan is not installed.\n",
       "Install from source: install.packages('RasterMan_1.0.0.tar.gz', repos=NULL, type='source')")
}

RasterMan::plot_trans_eqtl_cli()
